using System;
using System.Drawing;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Forms;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator
{
    public partial class MainForm : Form
    {
        private readonly TrafficController _controller = new();
        private DashboardForm _dashboardView = null!;
        private MealyDiagramForm _mealyView = null!;
        private AnalyticsForm _analyticsView = null!;

        public MainForm()
        {
            InitializeComponent();
            BuildNativeWinFormsLayout();

            _simulationTimer.Tick += (_, _) => _controller.Tick(0.05f);
            _controller.SimulationUpdated += (_, _) => UpdateHeaderStatus();
            _controller.LogRecorded += (_, rec) =>
            {
                _eventLogListBox.Items.Insert(0, rec.ToString());
                if (_eventLogListBox.Items.Count > 200)
                    _eventLogListBox.Items.RemoveAt(_eventLogListBox.Items.Count - 1);
            };

            UpdateHeaderStatus();
        }

        private void BuildNativeWinFormsLayout()
        {
            // 1. Top Header Bar (#191F28)
            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 68,
                BackColor = Color.FromArgb(20, 27, 38),
                Padding = new Padding(18, 8, 18, 8)
            };

            var headerLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = Color.Transparent,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };
            headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58F));
            headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42F));

            var brandTitle = new Label
            {
                Text = "SMART TRAFFIC CONTROL — MEALY MACHINE INTERSECTION SIMULATOR",
                Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(241, 245, 249),
                AutoSize = false,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true,
                Margin = new Padding(0, 0, 12, 0)
            };

            _topStatusLabel = new Label
            {
                Text = "STATE: S0 — NORTH/SOUTH GREEN",
                Font = new Font("Consolas", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(74, 222, 128),
                AutoSize = false,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                AutoEllipsis = true,
                Margin = new Padding(8, 0, 0, 0)
            };

            headerLayout.Controls.Add(brandTitle, 0, 0);
            headerLayout.Controls.Add(_topStatusLabel, 1, 0);
            headerPanel.Controls.Add(headerLayout);

            // 2. Right Interactive Control Panel (Sections A, B, C, D, E)
            var rightControlPanel = CreateInteractiveControlSidebar();

            // 3. Central TabControl (Main Dashboard, Mealy Machine Diagram, Traffic Analytics, System Log)
            _navigationTabs = new TabControl
            {
                Dock = DockStyle.Fill,
                DrawMode = TabDrawMode.OwnerDrawFixed,
                SizeMode = TabSizeMode.Fixed,
                ItemSize = new Size(154, 38),
                Padding = new Point(14, 5),
                Appearance = TabAppearance.Normal
            };
            _navigationTabs.DrawItem += DrawNavigationTab;

            var tabDashboard = new TabPage("Main Dashboard") { BackColor = Color.FromArgb(16, 19, 24) };
            _dashboardView = new DashboardForm(_controller);
            tabDashboard.Controls.Add(_dashboardView);

            var tabMealy = new TabPage("Mealy Machine Diagram") { BackColor = Color.FromArgb(16, 19, 24) };
            _mealyView = new MealyDiagramForm(_controller);
            tabMealy.Controls.Add(_mealyView);

            var tabAnalytics = new TabPage("Traffic Analytics") { BackColor = Color.FromArgb(16, 19, 24) };
            _analyticsView = new AnalyticsForm(_controller);
            tabAnalytics.Controls.Add(_analyticsView);

            var tabLogs = new TabPage("System Event Log") { BackColor = Color.FromArgb(16, 19, 24) };
            _eventLogListBox = new ListBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(13, 18, 27),
                ForeColor = Color.FromArgb(203, 213, 225),
                Font = new Font("Cascadia Mono", 9F),
                BorderStyle = BorderStyle.None,
                IntegralHeight = false,
                HorizontalScrollbar = true
            };
            var clearLogBtn = new Button
            {
                Text = "Clear Event Log",
                Dock = DockStyle.Bottom,
                Height = 42,
                BackColor = Color.FromArgb(127, 29, 29),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            clearLogBtn.FlatAppearance.BorderSize = 0;
            clearLogBtn.Click += (_, _) => _eventLogListBox.Items.Clear();
            tabLogs.Controls.Add(_eventLogListBox);
            tabLogs.Controls.Add(clearLogBtn);

            _navigationTabs.TabPages.Add(tabDashboard);
            _navigationTabs.TabPages.Add(tabMealy);
            _navigationTabs.TabPages.Add(tabAnalytics);
            _navigationTabs.TabPages.Add(tabLogs);

            Controls.Add(_navigationTabs);
            Controls.Add(rightControlPanel);
            Controls.Add(headerPanel);
        }

        private Panel CreateInteractiveControlSidebar()
        {
            var sidebar = new Panel
            {
                Dock = DockStyle.Right,
                Width = 376,
                MinimumSize = new Size(330, 0),
                BackColor = Color.FromArgb(20, 27, 38),
                Padding = new Padding(14, 12, 14, 12)
            };

            var flowLayout = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };

            sidebar.Controls.Add(flowLayout);

            // A. Simulation Controls
            flowLayout.Controls.Add(CreateSectionTitle("A. SIMULATION CONTROLS"));

            var simButtonRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 0, 0, 8)
            };
            simButtonRow.Controls.Add(CreateSidebarButton("Start", 92, Color.FromArgb(34, 197, 94), (_, _) => _controller.Start()));
            simButtonRow.Controls.Add(CreateSidebarButton("Pause", 92, Color.FromArgb(234, 179, 8), (_, _) => _controller.Pause()));
            simButtonRow.Controls.Add(CreateSidebarButton("Resume", 92, Color.FromArgb(59, 130, 246), (_, _) => _controller.Resume()));
            simButtonRow.Controls.Add(CreateSidebarButton("Reset", 92, Color.FromArgb(239, 68, 68), (_, _) => _controller.Reset()));
            flowLayout.Controls.Add(simButtonRow);

            var stepButtonRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 0, 0, 12)
            };
            stepButtonRow.Controls.Add(CreateSidebarButton("Step Next State →", 190, Color.FromArgb(139, 92, 246), (_, _) => _controller.StepNextState("Manual Step Button")));

            var modeButton = CreateSidebarButton("Mode: AUTO", 190, Color.FromArgb(51, 65, 85), (s, _) =>
            {
                _controller.IsAutoMode = !_controller.IsAutoMode;
                ((Button)s!).Text = _controller.IsAutoMode ? "Mode: AUTO" : "Mode: MANUAL";
                _controller.RecalculateMealyState();
            });
            stepButtonRow.Controls.Add(modeButton);
            flowLayout.Controls.Add(stepButtonRow);

            // B. Traffic Density Sliders & Turn Sensors
            flowLayout.Controls.Add(CreateSectionTitle("B. TRAFFIC DENSITY & TURN SENSORS"));
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                var row = new FlowLayoutPanel
                {
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    Margin = new Padding(0, 0, 0, 8)
                };

                var lbl = new Label
                {
                    Text = $"{dir}: {_controller.Sensors[dir].DensityPercent}% ({_controller.Sensors[dir].Congestion})",
                    AutoSize = true,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 9F),
                    Margin = new Padding(0, 6, 12, 0),
                    MinimumSize = new Size(88, 0),
                    MaximumSize = new Size(112, 36),
                    AutoEllipsis = true
                };
                var slider = new TrackBar
                {
                    Minimum = 0,
                    Maximum = 100,
                    Value = _controller.Sensors[dir].DensityPercent,
                    TickFrequency = 25,
                    Width = 174,
                    Height = 32,
                    AutoSize = false
                };
                slider.Scroll += (_, _) =>
                {
                    _controller.SetTrafficDensity(dir, slider.Value);
                    lbl.Text = $"{dir}: {slider.Value}% ({_controller.Sensors[dir].Congestion})";
                };
                row.Controls.Add(lbl);
                row.Controls.Add(slider);
                flowLayout.Controls.Add(row);
            }

            // C. Pedestrian Crossing Requests
            flowLayout.Controls.Add(CreateSectionTitle("C. PEDESTRIAN CROSSING REQUESTS"));
            var pedButtonRow = new TableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 2,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                BackColor = Color.Transparent,
                Margin = new Padding(0, 0, 0, 12),
                Padding = new Padding(0),
                Width = 330
            };
            pedButtonRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            pedButtonRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            pedButtonRow.RowStyles.Add(new RowStyle(SizeType.Absolute, 42F));
            pedButtonRow.RowStyles.Add(new RowStyle(SizeType.Absolute, 42F));
            AddWalkButton(pedButtonRow, "↑  WALK NORTH", Direction.North, 0, 0);
            AddWalkButton(pedButtonRow, "↓  WALK SOUTH", Direction.South, 1, 0);
            AddWalkButton(pedButtonRow, "→  WALK EAST", Direction.East, 0, 1);
            AddWalkButton(pedButtonRow, "←  WALK WEST", Direction.West, 1, 1);
            flowLayout.Controls.Add(pedButtonRow);

            // D. Emergency Controls (Maroon & Red Accents)
            flowLayout.Controls.Add(CreateSectionTitle("D. EMERGENCY VEHICLE PRIORITY"));
            var emerButtonRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 0, 0, 8)
            };
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                emerButtonRow.Controls.Add(CreateSidebarButton($"Emergency {dir}", 150, Color.FromArgb(159, 18, 57),
                    (_, _) => _controller.TriggerEmergency(dir)));
            }
            flowLayout.Controls.Add(emerButtonRow);

            flowLayout.Controls.Add(CreateSidebarButton("Clear Emergency Priority", 326, Color.FromArgb(71, 85, 105),
                (_, _) => _controller.ClearEmergency(), new Padding(0, 0, 0, 12)));

            // E. Manual Phase Selection (S0 - S9)
            flowLayout.Controls.Add(CreateSectionTitle("E. MANUAL PHASE SELECTION (S0–S9)"));
            var phaseButtonRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 0, 0, 8)
            };
            foreach (TrafficStateId st in Enum.GetValues(typeof(TrafficStateId)))
            {
                var meta = TrafficStateMetadata.All[st];
                phaseButtonRow.Controls.Add(CreateSidebarButton($"{meta.Code}: {meta.ShortName}", 190, Color.FromArgb(30, 41, 59),
                    (_, _) => _controller.SelectManualPhase(st)));
            }
            flowLayout.Controls.Add(phaseButtonRow);

            flowLayout.Controls.Add(CreateSidebarButton("Sync All Signals to Mealy Output", 326, Color.FromArgb(59, 130, 246),
                (_, _) => _controller.ClearLampOverrides(), new Padding(0, 8, 0, 0)));

            return sidebar;
        }

        private void AddWalkButton(TableLayoutPanel grid, string text, Direction direction, int column, int row)
        {
            var button = CreateSidebarButton(text, 154, Color.FromArgb(6, 95, 70),
                (_, _) => _controller.RequestPedestrianCrossing(direction), new Padding(3));
            button.Dock = DockStyle.Fill;
            button.Font = new Font("Segoe UI Semibold", 8.2F, FontStyle.Bold);
            button.FlatAppearance.BorderColor = Color.FromArgb(16, 185, 129);
            grid.Controls.Add(button, column, row);
        }

        private void DrawNavigationTab(object? sender, DrawItemEventArgs e)
        {
            if (sender is not TabControl tabs || e.Index < 0) return;
            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            var bounds = e.Bounds;
            bounds.Inflate(-3, -3);
            using var background = new SolidBrush(selected ? Color.FromArgb(37, 55, 79) : Color.FromArgb(25, 34, 48));
            using var border = new Pen(selected ? Color.FromArgb(96, 165, 250) : Color.FromArgb(45, 58, 76));
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.FillRectangle(background, bounds);
            e.Graphics.DrawRectangle(border, bounds);
            using var tabFont = new Font("Segoe UI Semibold", 8.5F, selected ? FontStyle.Bold : FontStyle.Regular);
            TextRenderer.DrawText(e.Graphics, tabs.TabPages[e.Index].Text,
                tabFont,
                bounds, selected ? Color.White : Color.FromArgb(160, 174, 192),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            if (selected)
            {
                using var accent = new Pen(Color.FromArgb(96, 165, 250), 3f);
                e.Graphics.DrawLine(accent, bounds.Left + 12, bounds.Bottom - 2, bounds.Right - 12, bounds.Bottom - 2);
            }
        }

        private void UpdateHeaderStatus()
        {
            var meta = TrafficStateMetadata.All[_controller.CurrentState];
            _topStatusLabel.Text =
                $"STATE: {meta.Code} ({meta.Name}) | TIMER: {_controller.PhaseElapsedSeconds:0.0}s / {_controller.CurrentInput.TargetPhaseDurationSeconds:0.0}s";
        }

        private static Label CreateSectionTitle(string title)
        {
            return new Label
            {
                Text = title,
                Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(125, 166, 255),
                AutoSize = true,
                Margin = new Padding(0, 14, 0, 8),
                Padding = new Padding(0, 0, 0, 4)
            };
        }

        private static Button CreateSidebarButton(string text, int width, Color backColor, EventHandler onClick, Padding? margin = null)
        {
            var btn = new Button
            {
                Text = text,
                Size = new Size(width, 36),
                MinimumSize = new Size(0, 34),
                BackColor = backColor,
                ForeColor = Color.FromArgb(248, 250, 252),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Margin = margin ?? new Padding(0, 0, 7, 7),
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = ControlPaint.Dark(backColor, 0.18f);
            btn.FlatAppearance.MouseOverBackColor = ControlPaint.Light(backColor, 0.14f);
            btn.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(backColor, 0.16f);
            btn.Click += onClick;
            return btn;
        }
    }
}
