using System.Drawing;
using System.Windows.Forms;

namespace TrafficLightSimulator
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer? components = null;
        private System.Windows.Forms.Timer _simulationTimer = null!;
        private TabControl _navigationTabs = null!;
        private Label _topStatusLabel = null!;
        private ListBox _eventLogListBox = null!;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._simulationTimer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();

            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(1440, 900);
            this.MinimumSize = new Size(1080, 700);
            this.BackColor = Color.FromArgb(13, 18, 27);
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            this.Text = "Smart Traffic Light Intersection Simulator — Native C# .NET 8 WinForms Mealy Machine";
            this.StartPosition = FormStartPosition.CenterScreen;

            this._simulationTimer.Interval = 50; // 20 FPS
            this._simulationTimer.Enabled = true;

            this.ResumeLayout(false);
        }
    }
}
