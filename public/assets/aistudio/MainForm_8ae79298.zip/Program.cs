using System;
using System.Windows.Forms;

namespace TrafficLightSimulator
{
    internal static class Program
    {
        /// <summary>
        /// Main entry point for the native .NET 8 Windows Forms Smart Traffic Light Intersection Simulator.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
