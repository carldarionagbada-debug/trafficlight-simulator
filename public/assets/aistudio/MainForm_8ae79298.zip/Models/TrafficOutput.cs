using System;
using System.Collections.Generic;

namespace TrafficLightSimulator.Models
{
    /// <summary>
    /// Complete Mealy Machine output vector Λ = λ(S, Σ) across all 4 approaches.
    /// </summary>
    public sealed class TrafficOutput
    {
        public Dictionary<Direction, TrafficSignal> Signals { get; } = new();
        public string ActiveGreenSummary { get; set; } = "ALL RED — Clearance Interlock";
        public string PhaseDescription { get; set; } = string.Empty;
        public double AdaptiveExtensionSeconds { get; set; }
        public bool ConflictSafetyVerified { get; set; } = true;
        public string MealyRuleApplied { get; set; } = string.Empty;

        public TrafficOutput()
        {
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                Signals[dir] = new TrafficSignal(dir);
            }
        }

        public TrafficOutput Clone()
        {
            var copy = new TrafficOutput
            {
                ActiveGreenSummary = ActiveGreenSummary,
                PhaseDescription = PhaseDescription,
                AdaptiveExtensionSeconds = AdaptiveExtensionSeconds,
                ConflictSafetyVerified = ConflictSafetyVerified,
                MealyRuleApplied = MealyRuleApplied
            };
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                copy.Signals[dir] = Signals[dir].Clone();
            }
            return copy;
        }
    }
}
