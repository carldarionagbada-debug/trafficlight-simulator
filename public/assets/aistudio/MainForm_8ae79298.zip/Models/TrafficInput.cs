using System;
using System.Collections.Generic;

namespace TrafficLightSimulator.Models
{
    public sealed class DirectionSensorSnapshot
    {
        public Direction Direction { get; set; }
        public int DensityPercent { get; set; }
        public CongestionLevel Congestion { get; set; }
        public int VehicleCount { get; set; }
        public bool LeftTurnDemand { get; set; }
        public bool RightTurnDemand { get; set; }
        public bool PedestrianRequest { get; set; }
    }

    /// <summary>
    /// Represents the complete input vector Σ passed to the Mealy Machine at every simulation step.
    /// </summary>
    public sealed class TrafficInput
    {
        public Dictionary<Direction, DirectionSensorSnapshot> Sensors { get; } = new();
        public bool EmergencyActive { get; set; }
        public Direction? EmergencyDirection { get; set; }
        public bool TimerExpired { get; set; }
        public double PhaseElapsedSeconds { get; set; }
        public double TargetPhaseDurationSeconds { get; set; } = 8.0;
        public TrafficStateId? ManualOverrideState { get; set; }
        public bool IsAutoMode { get; set; } = true;

        public TrafficInput()
        {
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                Sensors[dir] = new DirectionSensorSnapshot
                {
                    Direction = dir,
                    DensityPercent = 35,
                    Congestion = CongestionLevel.Medium,
                    VehicleCount = 0,
                    LeftTurnDemand = true,
                    RightTurnDemand = true,
                    PedestrianRequest = false
                };
            }
        }

        public bool HasNorthSouthLeftDemand =>
            Sensors[Direction.North].LeftTurnDemand || Sensors[Direction.South].LeftTurnDemand;

        public bool HasEastWestLeftDemand =>
            Sensors[Direction.East].LeftTurnDemand || Sensors[Direction.West].LeftTurnDemand;

        public bool HasAnyRightTurnDemand =>
            Sensors[Direction.North].RightTurnDemand ||
            Sensors[Direction.South].RightTurnDemand ||
            Sensors[Direction.East].RightTurnDemand ||
            Sensors[Direction.West].RightTurnDemand;

        public bool HasAnyPedestrianRequest =>
            Sensors[Direction.North].PedestrianRequest ||
            Sensors[Direction.South].PedestrianRequest ||
            Sensors[Direction.East].PedestrianRequest ||
            Sensors[Direction.West].PedestrianRequest;
    }
}
