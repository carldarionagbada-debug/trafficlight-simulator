using System;
using System.Drawing;

namespace TrafficLightSimulator.Models
{
    /// <summary>
    /// Represents an individual moving vehicle in one of the 12 approach lanes (North/South/East/West x Left/Straight/Right).
    /// </summary>
    public sealed class Vehicle
    {
        public string Id { get; } = Guid.NewGuid().ToString("N")[..8];
        public Direction Origin { get; }
        public LaneType Lane { get; }
        public float Progress { get; set; } // 0.0 (spawn) -> 0.34 (stop line) -> 0.66 (intersection exit) -> 1.0 (off-screen)
        public float Speed { get; set; }
        public float MaxSpeed { get; }
        public Color Color { get; }
        public float Length { get; }
        public float Width { get; }
        public double WaitTimeSeconds { get; set; }
        public bool IsEmergency { get; }

        public Vehicle(Direction origin, LaneType lane, Color color, bool isEmergency = false)
        {
            Origin = origin;
            Lane = lane;
            Color = color;
            IsEmergency = isEmergency;
            Length = isEmergency ? 28f : 26f;
            Width = isEmergency ? 16f : 15f;
            MaxSpeed = isEmergency ? 0.34f : 0.21f;
            Speed = MaxSpeed;
            Progress = 0.0f;
        }

        public void StepKinematics(float dt, bool laneSignalGreen, float? leaderProgress)
        {
            const float stopLine = 0.335f;
            const float minGap = 0.072f;

            bool blockedByLeader = leaderProgress.HasValue && (leaderProgress.Value - Progress) < minGap;
            bool mustStopAtLine = !laneSignalGreen && Progress < stopLine && (stopLine - Progress) < 0.055f;

            if (blockedByLeader || mustStopAtLine)
            {
                Speed = 0f;
                if (Progress < stopLine)
                {
                    WaitTimeSeconds += dt;
                }
            }
            else
            {
                Speed = Math.Min(MaxSpeed, Speed + dt * 0.45f);
                Progress += Speed * dt;
            }
        }
    }
}
