using System;
using System.Collections.Generic;

namespace TrafficLightSimulator.Models
{
    public enum TrafficStateId
    {
        S0_NorthSouthGreen = 0,
        S1_NorthSouthLeftTurn = 1,
        S2_NorthSouthYellow = 2,
        S3_AllRedClearance1 = 3,
        S4_EastWestGreen = 4,
        S5_EastWestLeftTurn = 5,
        S6_EastWestYellow = 6,
        S7_AllRedClearance2 = 7,
        S8_RightTurnPhase = 8,
        S9_EmergencyPriority = 9
    }

    public enum Direction
    {
        North = 0,
        South = 1,
        East = 2,
        West = 3
    }

    public enum LaneType
    {
        LeftTurn = 0,
        Straight = 1,
        RightTurn = 2
    }

    public enum CongestionLevel
    {
        Low = 0,
        Medium = 1,
        High = 2,
        Critical = 3
    }

    public sealed class TrafficStateMetadata
    {
        public TrafficStateId Id { get; }
        public string Code { get; }
        public string Name { get; }
        public string ShortName { get; }
        public double BaseDurationSeconds { get; }
        public string Description { get; }
        public string DefaultOutputSummary { get; }

        public TrafficStateMetadata(
            TrafficStateId id,
            string code,
            string name,
            string shortName,
            double baseDurationSeconds,
            string description,
            string defaultOutputSummary)
        {
            Id = id;
            Code = code;
            Name = name;
            ShortName = shortName;
            BaseDurationSeconds = baseDurationSeconds;
            Description = description;
            DefaultOutputSummary = defaultOutputSummary;
        }

        public static readonly IReadOnlyDictionary<TrafficStateId, TrafficStateMetadata> All =
            new Dictionary<TrafficStateId, TrafficStateMetadata>
            {
                [TrafficStateId.S0_NorthSouthGreen] = new(
                    TrafficStateId.S0_NorthSouthGreen, "S0", "NORTH/SOUTH GREEN", "N/S Green", 8.0,
                    "North and South straight lanes GREEN. Left-turn arrows RED. East and West RED.",
                    "N/S: GRN · E/W: RED"),
                [TrafficStateId.S1_NorthSouthLeftTurn] = new(
                    TrafficStateId.S1_NorthSouthLeftTurn, "S1", "NORTH/SOUTH LEFT TURN", "N/S Left Turn", 6.0,
                    "Protected North and South left-turn GREEN arrows. Straight lanes RED. East/West RED.",
                    "N/S L-ARR: GRN"),
                [TrafficStateId.S2_NorthSouthYellow] = new(
                    TrafficStateId.S2_NorthSouthYellow, "S2", "NORTH/SOUTH YELLOW", "N/S Yellow", 3.0,
                    "North and South warning YELLOW phase. All turn arrows RED. East/West RED.",
                    "N/S: YEL · ALL ARR: RED"),
                [TrafficStateId.S3_AllRedClearance1] = new(
                    TrafficStateId.S3_AllRedClearance1, "S3", "ALL RED CLEARANCE 1", "All Red 1", 2.0,
                    "All vehicle signals RED to allow safe intersection clearance before E/W phase.",
                    "ALL SIGNALS: RED"),
                [TrafficStateId.S4_EastWestGreen] = new(
                    TrafficStateId.S4_EastWestGreen, "S4", "EAST/WEST GREEN", "E/W Green", 8.0,
                    "East and West straight lanes GREEN. Left-turn arrows RED. North and South RED.",
                    "E/W: GRN · N/S: RED"),
                [TrafficStateId.S5_EastWestLeftTurn] = new(
                    TrafficStateId.S5_EastWestLeftTurn, "S5", "EAST/WEST LEFT TURN", "E/W Left Turn", 6.0,
                    "Protected East and West left-turn GREEN arrows. Straight lanes RED. North/South RED.",
                    "E/W L-ARR: GRN"),
                [TrafficStateId.S6_EastWestYellow] = new(
                    TrafficStateId.S6_EastWestYellow, "S6", "EAST/WEST YELLOW", "E/W Yellow", 3.0,
                    "East and West warning YELLOW phase. All turn arrows RED. North/South RED.",
                    "E/W: YEL · ALL ARR: RED"),
                [TrafficStateId.S7_AllRedClearance2] = new(
                    TrafficStateId.S7_AllRedClearance2, "S7", "ALL RED CLEARANCE 2", "All Red 2", 2.0,
                    "All vehicle signals RED to allow safe intersection clearance before next cycle.",
                    "ALL SIGNALS: RED"),
                [TrafficStateId.S8_RightTurnPhase] = new(
                    TrafficStateId.S8_RightTurnPhase, "S8", "RIGHT TURN PHASE", "Right Turn Phase", 5.0,
                    "Protected right-turn phase for non-conflicting approaches and requested pedestrian crossings.",
                    "R-ARR: GRN · WALK"),
                [TrafficStateId.S9_EmergencyPriority] = new(
                    TrafficStateId.S9_EmergencyPriority, "S9", "EMERGENCY PRIORITY", "Emergency Priority", 7.0,
                    "Emergency vehicle preemption phase. Clears conflicting movements and grants full corridor green.",
                    "EMERG DIR: FULL GRN")
            };
    }
}
