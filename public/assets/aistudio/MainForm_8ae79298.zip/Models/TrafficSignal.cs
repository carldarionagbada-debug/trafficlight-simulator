using System;

namespace TrafficLightSimulator.Models
{
    public enum LightColor
    {
        Red = 0,
        Yellow = 1,
        Green = 2
    }

    public enum ArrowSignal
    {
        RedArrow = 0,
        GreenArrow = 1
    }

    public enum PedestrianSignal
    {
        DontWalk = 0,
        Walk = 1
    }

    /// <summary>
    /// Represents all 9 signal outputs for a single approach (North, South, East, or West),
    /// plus optional interactive lamp overrides when the user clicks directly on a traffic light.
    /// </summary>
    public sealed class TrafficSignal
    {
        public Direction Approach { get; }
        public LightColor StandardLight { get; set; } = LightColor.Red;
        public ArrowSignal LeftArrow { get; set; } = ArrowSignal.RedArrow;
        public ArrowSignal RightArrow { get; set; } = ArrowSignal.RedArrow;
        public PedestrianSignal Pedestrian { get; set; } = PedestrianSignal.DontWalk;

        public bool IsRed => StandardLight == LightColor.Red;
        public bool IsYellow => StandardLight == LightColor.Yellow;
        public bool IsGreen => StandardLight == LightColor.Green;
        public bool IsLeftGreen => LeftArrow == ArrowSignal.GreenArrow;
        public bool IsLeftRed => LeftArrow == ArrowSignal.RedArrow;
        public bool IsRightGreen => RightArrow == ArrowSignal.GreenArrow;
        public bool IsRightRed => RightArrow == ArrowSignal.RedArrow;
        public bool IsWalk => Pedestrian == PedestrianSignal.Walk;
        public bool IsDontWalk => Pedestrian == PedestrianSignal.DontWalk;

        public TrafficSignal(Direction approach)
        {
            Approach = approach;
        }

        public TrafficSignal Clone()
        {
            return new TrafficSignal(Approach)
            {
                StandardLight = StandardLight,
                LeftArrow = LeftArrow,
                RightArrow = RightArrow,
                Pedestrian = Pedestrian
            };
        }
    }

    public sealed class ManualLampOverride
    {
        public LightColor? StandardLight { get; set; }
        public ArrowSignal? LeftArrow { get; set; }
        public ArrowSignal? RightArrow { get; set; }
        public PedestrianSignal? Pedestrian { get; set; }

        public bool HasAny =>
            StandardLight.HasValue || LeftArrow.HasValue || RightArrow.HasValue || Pedestrian.HasValue;

        public void Clear()
        {
            StandardLight = null;
            LeftArrow = null;
            RightArrow = null;
            Pedestrian = null;
        }
    }
}
