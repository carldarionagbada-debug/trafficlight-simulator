using System;

namespace TrafficLightSimulator.Models
{
    /// <summary>
    /// Per-direction inductive loop & camera traffic sensor model.
    /// Tracks traffic density (0-100%), congestion classification, vehicle queue count,
    /// left/right turn demands, and pedestrian crossing push-button requests.
    /// </summary>
    public sealed class TrafficSensor
    {
        public Direction Direction { get; }
        private int _densityPercent;

        public int DensityPercent
        {
            get => _densityPercent;
            set => _densityPercent = Math.Clamp(value, 0, 100);
        }

        public int VehicleCount { get; set; }
        public bool LeftTurnDemand { get; set; } = true;
        public bool RightTurnDemand { get; set; } = true;
        public bool PedestrianRequest { get; set; }

        public TrafficSensor(Direction direction, int initialDensity = 35)
        {
            Direction = direction;
            DensityPercent = initialDensity;
        }

        public CongestionLevel Congestion => DensityToCongestion(_densityPercent);

        public static CongestionLevel DensityToCongestion(int density)
        {
            if (density >= 80) return CongestionLevel.Critical;
            if (density >= 55) return CongestionLevel.High;
            if (density >= 25) return CongestionLevel.Medium;
            return CongestionLevel.Low;
        }

        public static int CongestionWeight(CongestionLevel level) => level switch
        {
            CongestionLevel.Critical => 4,
            CongestionLevel.High => 3,
            CongestionLevel.Medium => 2,
            _ => 1
        };

        public DirectionSensorSnapshot ToSnapshot() => new()
        {
            Direction = Direction,
            DensityPercent = DensityPercent,
            Congestion = Congestion,
            VehicleCount = VehicleCount,
            LeftTurnDemand = LeftTurnDemand,
            RightTurnDemand = RightTurnDemand,
            PedestrianRequest = PedestrianRequest
        };
    }
}
