using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controls
{
    /// <summary>
    /// Custom double-buffered WinForms UserControl rendering the 4-way road intersection,
    /// 12 lanes, road directional arrows, zebra crosswalks, curved vehicle trajectories,
    /// and interactive clickable traffic light housings.
    /// </summary>
    public sealed class IntersectionControl : UserControl
    {
        private readonly TrafficController _controller;
        private readonly List<SignalHitZone> _hitZones = new();
        private SignalHitZone? _hoveredZone;

        public IntersectionControl(TrafficController controller)
        {
            _controller = controller;
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.FromArgb(13, 17, 23);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            PointF virtualPt = ToVirtualCoords(e.Location);
            var hit = _hitZones.FirstOrDefault(z => z.Bounds.Contains(virtualPt));
            if (hit != _hoveredZone)
            {
                _hoveredZone = hit;
                Cursor = _hoveredZone != null ? Cursors.Hand : Cursors.Default;
                Invalidate();
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            PointF virtualPt = ToVirtualCoords(e.Location);
            var hit = _hitZones.FirstOrDefault(z => z.Bounds.Contains(virtualPt));
            hit?.Invoke();
        }

        private PointF ToVirtualCoords(Point clientPt)
        {
            if (Width <= 0 || Height <= 0) return new PointF();
            float scale = Math.Min(Width / 840f, Height / 840f);
            if (scale <= 0) return new PointF();
            float offsetX = (Width - 840f * scale) / 2f;
            float offsetY = (Height - 840f * scale) / 2f;
            return new PointF((clientPt.X - offsetX) / scale, (clientPt.Y - offsetY) / scale);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (Width <= 0 || Height <= 0) return;
            float scale = Math.Min(Width / 840f, Height / 840f);
            if (scale <= 0) return;
            float offsetX = (Width - 840f * scale) / 2f;
            float offsetY = (Height - 840f * scale) / 2f;

            g.TranslateTransform(offsetX, offsetY);
            g.ScaleTransform(scale, scale);

            const float SIZE = 840f;
            const float CENTER = 420f;
            const float ROAD_HALF = 126f;
            const float ROAD_MIN = CENTER - ROAD_HALF; // 294
            const float ROAD_MAX = CENTER + ROAD_HALF; // 546
            const float LANE_W = 42f;

            // 1. Sidewalk blocks
            using var curbBrush = new SolidBrush(Color.FromArgb(22, 28, 36));
            g.FillRectangle(curbBrush, 0, 0, ROAD_MIN, ROAD_MIN);
            g.FillRectangle(curbBrush, ROAD_MAX, 0, SIZE - ROAD_MAX, ROAD_MIN);
            g.FillRectangle(curbBrush, 0, ROAD_MAX, ROAD_MIN, SIZE - ROAD_MAX);
            g.FillRectangle(curbBrush, ROAD_MAX, ROAD_MAX, SIZE - ROAD_MAX, SIZE - ROAD_MAX);

            // 2. Asphalt Road Surfaces
            using var roadBrush = new SolidBrush(Color.FromArgb(30, 37, 48));
            g.FillRectangle(roadBrush, ROAD_MIN, 0, ROAD_HALF * 2, SIZE);
            g.FillRectangle(roadBrush, 0, ROAD_MIN, SIZE, ROAD_HALF * 2);

            if (_controller.EmergencyActive && _controller.EmergencyDirection.HasValue)
            {
                using var emCorridorBrush = new SolidBrush(Color.FromArgb(40, 239, 68, 68));
                var emDir = _controller.EmergencyDirection.Value;
                if (emDir == Direction.North || emDir == Direction.South)
                    g.FillRectangle(emCorridorBrush, ROAD_MIN, 0, ROAD_HALF * 2, SIZE);
                else
                    g.FillRectangle(emCorridorBrush, 0, ROAD_MIN, SIZE, ROAD_HALF * 2);
            }

            // 3. Dashed Lane Dividers & Double Yellow Centerlines
            using var dashPen = new Pen(Color.FromArgb(80, 226, 232, 240), 1.5f) { DashPattern = new[] { 12f, 10f } };
            foreach (float offset in new[] { LANE_W, LANE_W * 2 })
            {
                foreach (int sign in new[] { -1, 1 })
                {
                    float x = CENTER + sign * offset;
                    g.DrawLine(dashPen, x, 0, x, ROAD_MIN - 32);
                    g.DrawLine(dashPen, x, ROAD_MAX + 32, x, SIZE);

                    float y = CENTER + sign * offset;
                    g.DrawLine(dashPen, 0, y, ROAD_MIN - 32, y);
                    g.DrawLine(dashPen, ROAD_MAX + 32, y, SIZE, y);
                }
            }

            using var yellowPen = new Pen(Color.FromArgb(250, 204, 21), 2f);
            foreach (float d in new[] { -2.5f, 2.5f })
            {
                g.DrawLine(yellowPen, CENTER + d, 0, CENTER + d, ROAD_MIN - 32);
                g.DrawLine(yellowPen, CENTER + d, ROAD_MAX + 32, CENTER + d, SIZE);
                g.DrawLine(yellowPen, 0, CENTER + d, ROAD_MIN - 32, CENTER + d);
                g.DrawLine(yellowPen, ROAD_MAX + 32, CENTER + d, SIZE, CENTER + d);
            }

            // 4. Stop Lines & Zebra Crosswalks
            using var stopPen = new Pen(Color.White, 5f);
            g.DrawLine(stopPen, ROAD_MIN + 2, ROAD_MIN - 32, CENTER - 2, ROAD_MIN - 32);
            g.DrawLine(stopPen, CENTER + 2, ROAD_MAX + 32, ROAD_MAX - 2, ROAD_MAX + 32);
            g.DrawLine(stopPen, ROAD_MIN - 32, CENTER + 2, ROAD_MIN - 32, ROAD_MAX - 2);
            g.DrawLine(stopPen, ROAD_MAX + 32, ROAD_MIN + 2, ROAD_MAX + 32, CENTER - 2);

            using var zebraBrush = new SolidBrush(Color.FromArgb(145, 226, 232, 240));
            for (float x = ROAD_MIN + 8; x < ROAD_MAX - 8; x += 18)
            {
                g.FillRectangle(zebraBrush, x, ROAD_MIN - 26, 9, 20);
                g.FillRectangle(zebraBrush, x, ROAD_MAX + 6, 9, 20);
            }
            for (float y = ROAD_MIN + 8; y < ROAD_MAX - 8; y += 18)
            {
                g.FillRectangle(zebraBrush, ROAD_MIN - 26, y, 20, 9);
                g.FillRectangle(zebraBrush, ROAD_MAX + 6, y, 20, 9);
            }

            // 5. Draw Moving Vehicles along Straight & Curved Turn Trajectories
            foreach (var v in _controller.VehicleManager.Vehicles)
            {
                var (vx, vy, angleRad) = ComputeVehiclePose(v.Origin, v.Lane, v.Progress);
                GraphicsState state = g.Save();
                g.TranslateTransform(vx, vy);
                g.RotateTransform((float)(angleRad * 180.0 / Math.PI));

                using var carBrush = new SolidBrush(v.IsEmergency ? Color.White : v.Color);
                g.FillRectangle(carBrush, -v.Length / 2f, -v.Width / 2f, v.Length, v.Width);

                using var roofBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
                g.FillRectangle(roofBrush, -v.Length / 4f, -v.Width / 2f + 2.5f, v.Length * 0.5f, v.Width - 5f);

                g.Restore(state);
            }

            // 6. Draw 4 Interactive Corner Signal Housings
            _hitZones.Clear();
            TrafficLightControl.DrawHousing(g, 18, 18, "NORTHBOUND SIGNAL",
                _controller.CurrentOutput.Signals[Direction.North],
                _controller.CurrentInput.Sensors[Direction.North],
                _controller, _hitZones);

            TrafficLightControl.DrawHousing(g, SIZE - 256 - 18, 18, "EASTBOUND SIGNAL",
                _controller.CurrentOutput.Signals[Direction.East],
                _controller.CurrentInput.Sensors[Direction.East],
                _controller, _hitZones);

            TrafficLightControl.DrawHousing(g, 18, SIZE - 128 - 18, "WESTBOUND SIGNAL",
                _controller.CurrentOutput.Signals[Direction.West],
                _controller.CurrentInput.Sensors[Direction.West],
                _controller, _hitZones);

            TrafficLightControl.DrawHousing(g, SIZE - 256 - 18, SIZE - 128 - 18, "SOUTHBOUND SIGNAL",
                _controller.CurrentOutput.Signals[Direction.South],
                _controller.CurrentInput.Sensors[Direction.South],
                _controller, _hitZones);

            if (_hoveredZone != null)
            {
                using var hoverPen = new Pen(Color.FromArgb(196, 181, 253), 2f) { DashStyle = DashStyle.Dot };
                var b = _hoveredZone.Bounds;
                g.DrawRectangle(hoverPen, b.X - 2, b.Y - 2, b.Width + 4, b.Height + 4);
            }
        }

        private static (float X, float Y, double AngleRad) ComputeVehiclePose(Direction origin, LaneType lane, float progress)
        {
            float laneOffset = lane == LaneType.LeftTurn ? 21f : lane == LaneType.Straight ? 63f : 105f;
            const float stopCoord = 290f;
            const float farCoord = 550f;
            const float pStop = 0.34f;
            const float pExit = 0.66f;

            static (float X, float Y, double Angle) QuadBezier(float p0x, float p0y, float p1x, float p1y, float p2x, float p2y, float t)
            {
                float u = 1f - t;
                float x = u * u * p0x + 2f * u * t * p1x + t * t * p2x;
                float y = u * u * p0y + 2f * u * t * p1y + t * t * p2y;
                float dx = 2f * u * (p1x - p0x) + 2f * t * (p2x - p1x);
                float dy = 2f * u * (p1y - p0y) + 2f * t * (p2y - p1y);
                return (x, y, Math.Atan2(dy, dx));
            }

            if (origin == Direction.North)
            {
                float xIn = 420f - laneOffset;
                if (lane == LaneType.Straight) return (xIn, progress * 840f, Math.PI / 2);
                float yOut = lane == LaneType.RightTurn ? 315f : 441f;
                float xTarget = lane == LaneType.RightTurn ? stopCoord : farCoord;
                if (progress <= pStop) return (xIn, (progress / pStop) * stopCoord, Math.PI / 2);
                if (progress <= pExit) return QuadBezier(xIn, stopCoord, xIn, yOut, xTarget, yOut, (progress - pStop) / (pExit - pStop));
                float tOut = (progress - pExit) / (1f - pExit);
                return lane == LaneType.RightTurn
                    ? (stopCoord * (1f - tOut), yOut, Math.PI)
                    : (farCoord + tOut * (840f - farCoord), yOut, 0);
            }
            if (origin == Direction.South)
            {
                float xIn = 420f + laneOffset;
                if (lane == LaneType.Straight) return (xIn, 840f - progress * 840f, -Math.PI / 2);
                float yOut = lane == LaneType.RightTurn ? 525f : 399f;
                float xTarget = lane == LaneType.RightTurn ? farCoord : stopCoord;
                if (progress <= pStop) return (xIn, 840f - (progress / pStop) * stopCoord, -Math.PI / 2);
                if (progress <= pExit) return QuadBezier(xIn, farCoord, xIn, yOut, xTarget, yOut, (progress - pStop) / (pExit - pStop));
                float tOut = (progress - pExit) / (1f - pExit);
                return lane == LaneType.RightTurn
                    ? (farCoord + tOut * (840f - farCoord), yOut, 0)
                    : (stopCoord * (1f - tOut), yOut, Math.PI);
            }
            if (origin == Direction.West)
            {
                float yIn = 420f + laneOffset;
                if (lane == LaneType.Straight) return (progress * 840f, yIn, 0);
                float xOut = lane == LaneType.RightTurn ? 315f : 441f;
                float yTarget = lane == LaneType.RightTurn ? farCoord : stopCoord;
                if (progress <= pStop) return ((progress / pStop) * stopCoord, yIn, 0);
                if (progress <= pExit) return QuadBezier(stopCoord, yIn, xOut, yIn, xOut, yTarget, (progress - pStop) / (pExit - pStop));
                float tOut = (progress - pExit) / (1f - pExit);
                return lane == LaneType.RightTurn
                    ? (xOut, farCoord + tOut * (840f - farCoord), Math.PI / 2)
                    : (xOut, stopCoord * (1f - tOut), -Math.PI / 2);
            }
            else
            {
                float yIn = 420f - laneOffset;
                if (lane == LaneType.Straight) return (840f - progress * 840f, yIn, Math.PI);
                float xOut = lane == LaneType.RightTurn ? 525f : 399f;
                float yTarget = lane == LaneType.RightTurn ? stopCoord : farCoord;
                if (progress <= pStop) return (840f - (progress / pStop) * stopCoord, yIn, Math.PI);
                if (progress <= pExit) return QuadBezier(farCoord, yIn, xOut, yIn, xOut, yTarget, (progress - pStop) / (pExit - pStop));
                float tOut = (progress - pExit) / (1f - pExit);
                return lane == LaneType.RightTurn
                    ? (xOut, stopCoord * (1f - tOut), -Math.PI / 2)
                    : (xOut, farCoord + tOut * (840f - farCoord), Math.PI / 2);
            }
        }
    }
}
