using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controls
{
    public sealed class SignalHitZone
    {
        public RectangleF Bounds { get; init; }
        public string Tooltip { get; init; } = string.Empty;
        public Action Invoke { get; init; } = () => { };
    }

    /// <summary>
    /// Renders a multi-head traffic signal housing with clickable R/Y/G circular lenses,
    /// clickable Left-Turn Red/Green arrows, clickable Right-Turn Red/Green arrows,
    /// Pedestrian WALK / DON'T WALK indicator, and L-Dem / R-Dem sensor buttons.
    /// </summary>
    public static class TrafficLightControl
    {
        public static void DrawHousing(
            Graphics g,
            float x,
            float y,
            string title,
            TrafficSignal sig,
            DirectionSensorSnapshot sensor,
            TrafficController controller,
            List<SignalHitZone> hitZones)
        {
            const float W = 256f;
            const float H = 128f;
            Direction dir = sig.Approach;

            using var bgBrush = new SolidBrush(Color.FromArgb(242, 16, 19, 24));
            using var borderPen = new Pen(Color.FromArgb(51, 65, 85), 1.5f);
            g.FillRectangle(bgBrush, x, y, W, H);
            g.DrawRectangle(borderPen, x, y, W, H);

            using var headerBrush = new SolidBrush(Color.FromArgb(25, 31, 40));
            g.FillRectangle(headerBrush, x + 1, y + 1, W - 2, 25);

            using var headerFont = new Font("Segoe UI", 8.2f, FontStyle.Bold);
            using var smallMono = new Font("Consolas", 8f, FontStyle.Bold);
            using var titleFormat = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap };
            g.DrawString(title, headerFont, Brushes.White, new RectangleF(x + 8, y + 4, 148, 18), titleFormat);

            Color congColor = sensor.Congestion switch
            {
                CongestionLevel.Critical => Color.FromArgb(239, 68, 68),
                CongestionLevel.High => Color.FromArgb(249, 115, 22),
                CongestionLevel.Medium => Color.FromArgb(250, 204, 21),
                _ => Color.FromArgb(34, 197, 94)
            };
            using var congBrush = new SolidBrush(congColor);
            g.DrawString($"{sensor.Congestion} ({sensor.DensityPercent}%)", smallMono, congBrush, x + W - 96, y + 6);

            // Row 1: MAIN Standard Circular Lights (Red, Yellow, Green)
            g.DrawString("MAIN", smallMono, Brushes.Silver, x + 8, y + 37);

            DrawCircleLamp(g, x + 58, y + 44, sig.IsRed, Color.FromArgb(239, 68, 68), Color.FromArgb(59, 24, 27));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 46, y + 32, 24, 24),
                Tooltip = $"Set {dir} Main Signal -> RED",
                Invoke = () => controller.ClickStandardLamp(dir, LightColor.Red)
            });

            DrawCircleLamp(g, x + 84, y + 44, sig.IsYellow, Color.FromArgb(250, 204, 21), Color.FromArgb(61, 51, 20));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 72, y + 32, 24, 24),
                Tooltip = $"Set {dir} Main Signal -> YELLOW",
                Invoke = () => controller.ClickStandardLamp(dir, LightColor.Yellow)
            });

            DrawCircleLamp(g, x + 110, y + 44, sig.IsGreen, Color.FromArgb(34, 197, 94), Color.FromArgb(19, 54, 36));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 98, y + 32, 24, 24),
                Tooltip = $"Set {dir} Main Signal -> GREEN",
                Invoke = () => controller.ClickStandardLamp(dir, LightColor.Green)
            });

            // Pedestrian WALK / DON'T WALK Box
            var pedRect = new RectangleF(x + 132, y + 33, 114, 23);
            Color pedColor = sig.IsWalk ? Color.FromArgb(34, 197, 94) : Color.FromArgb(239, 68, 68);
            using var pedBorder = new Pen(pedColor, 1.2f);
            using var pedText = new SolidBrush(pedColor);
            g.DrawRectangle(pedBorder, pedRect.X, pedRect.Y, pedRect.Width, pedRect.Height);
            string pedLabel = sig.IsWalk ? "WALK" : (sensor.PedestrianRequest ? "WAIT (REQ)" : "DON'T WALK");
            g.DrawString(pedLabel, smallMono, pedText, pedRect.X + 6, pedRect.Y + 4);
            hitZones.Add(new SignalHitZone
            {
                Bounds = pedRect,
                Tooltip = $"Toggle {dir} Pedestrian WALK / DON'T WALK",
                Invoke = () => controller.TogglePedestrianWalk(dir)
            });

            // Row 2: Clickable L-TURN & R-TURN Arrow Lamps
            g.DrawString("L-TURN", smallMono, sig.IsLeftGreen ? Brushes.LightGreen : Brushes.Silver, x + 8, y + 69);
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 6, y + 64, 44, 24),
                Tooltip = $"Toggle {dir} Left-Turn Arrow",
                Invoke = () => controller.ToggleLeftArrow(dir)
            });

            DrawArrowLamp(g, x + 62, y + 76, isLeft: true, sig.IsLeftRed, Color.FromArgb(239, 68, 68), Color.FromArgb(69, 26, 28));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 50, y + 64, 24, 24),
                Tooltip = $"Set {dir} Left-Turn -> RED ARROW",
                Invoke = () => controller.ToggleLeftArrow(dir, ArrowSignal.RedArrow)
            });

            DrawArrowLamp(g, x + 90, y + 76, isLeft: true, sig.IsLeftGreen, Color.FromArgb(34, 197, 94), Color.FromArgb(20, 51, 35));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 78, y + 64, 24, 24),
                Tooltip = $"Set {dir} Left-Turn -> GREEN ARROW",
                Invoke = () => controller.ToggleLeftArrow(dir, ArrowSignal.GreenArrow)
            });

            g.DrawString("R-TURN", smallMono, sig.IsRightGreen ? Brushes.LightGreen : Brushes.Silver, x + 130, y + 69);
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 128, y + 64, 48, 24),
                Tooltip = $"Toggle {dir} Right-Turn Arrow",
                Invoke = () => controller.ToggleRightArrow(dir)
            });

            DrawArrowLamp(g, x + 190, y + 76, isLeft: false, sig.IsRightRed, Color.FromArgb(239, 68, 68), Color.FromArgb(69, 26, 28));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 178, y + 64, 24, 24),
                Tooltip = $"Set {dir} Right-Turn -> RED ARROW",
                Invoke = () => controller.ToggleRightArrow(dir, ArrowSignal.RedArrow)
            });

            DrawArrowLamp(g, x + 218, y + 76, isLeft: false, sig.IsRightGreen, Color.FromArgb(34, 197, 94), Color.FromArgb(20, 51, 35));
            hitZones.Add(new SignalHitZone
            {
                Bounds = new RectangleF(x + 206, y + 64, 24, 24),
                Tooltip = $"Set {dir} Right-Turn -> GREEN ARROW",
                Invoke = () => controller.ToggleRightArrow(dir, ArrowSignal.GreenArrow)
            });

            // Row 3: Vehicle Queue & Clickable L-Dem / R-Dem Sensor Buttons
            g.DrawString($"Veh:{sensor.VehicleCount}", smallMono, Brushes.Gray, x + 8, y + 103);

            var lDemRect = new RectangleF(x + 88, y + 99, 74, 20);
            g.DrawRectangle(Pens.SlateGray, lDemRect.X, lDemRect.Y, lDemRect.Width, lDemRect.Height);
            g.DrawString($"L-Dem:{(sensor.LeftTurnDemand ? "ON" : "OFF")}", smallMono,
                sensor.LeftTurnDemand ? Brushes.Plum : Brushes.Gray, lDemRect.X + 4, lDemRect.Y + 3);
            hitZones.Add(new SignalHitZone
            {
                Bounds = lDemRect,
                Tooltip = $"Toggle {dir} Left-Turn Sensor Demand",
                Invoke = () => controller.ToggleTurnDemand(dir, isLeft: true)
            });

            var rDemRect = new RectangleF(x + 168, y + 99, 78, 20);
            g.DrawRectangle(Pens.SlateGray, rDemRect.X, rDemRect.Y, rDemRect.Width, rDemRect.Height);
            g.DrawString($"R-Dem:{(sensor.RightTurnDemand ? "ON" : "OFF")}", smallMono,
                sensor.RightTurnDemand ? Brushes.LightGreen : Brushes.Gray, rDemRect.X + 4, rDemRect.Y + 3);
            hitZones.Add(new SignalHitZone
            {
                Bounds = rDemRect,
                Tooltip = $"Toggle {dir} Right-Turn Sensor Demand",
                Invoke = () => controller.ToggleTurnDemand(dir, isLeft: false)
            });
        }

        private static void DrawCircleLamp(Graphics g, float cx, float cy, bool active, Color onColor, Color offColor)
        {
            using var brush = new SolidBrush(active ? onColor : offColor);
            using var pen = new Pen(active ? Color.White : Color.FromArgb(71, 85, 105), active ? 1.5f : 1f);
            g.FillEllipse(brush, cx - 9.5f, cy - 9.5f, 19f, 19f);
            g.DrawEllipse(pen, cx - 9.5f, cy - 9.5f, 19f, 19f);
        }

        private static void DrawArrowLamp(Graphics g, float cx, float cy, bool isLeft, bool active, Color onColor, Color offColor)
        {
            using var housing = new SolidBrush(Color.FromArgb(15, 23, 42));
            using var pen = new Pen(Color.FromArgb(71, 85, 105), 1f);
            g.FillEllipse(housing, cx - 9.5f, cy - 9.5f, 19f, 19f);
            g.DrawEllipse(pen, cx - 9.5f, cy - 9.5f, 19f, 19f);

            int sign = isLeft ? -1 : 1;
            using var arrowPen = new Pen(active ? onColor : offColor, 2.2f)
            {
                StartCap = LineCap.Round,
                EndCap = LineCap.ArrowAnchor
            };
            g.DrawLine(arrowPen, cx - sign * 5f, cy, cx + sign * 5f, cy);
        }
    }
}
