using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controls
{
    /// <summary>
    /// Custom WinForms UserControl that draws the interactive 10-State Mealy Machine graph (S0..S9)
    /// with directed transition arrows, condition labels, and clickable circular state nodes.
    /// </summary>
    public sealed class StateDiagramControl : UserControl
    {
        private readonly TrafficController _controller;

        private static readonly (TrafficStateId Id, float Cx, float Cy)[] Nodes =
        {
            (TrafficStateId.S0_NorthSouthGreen, 130f, 95f),
            (TrafficStateId.S1_NorthSouthLeftTurn, 340f, 95f),
            (TrafficStateId.S2_NorthSouthYellow, 550f, 95f),
            (TrafficStateId.S3_AllRedClearance1, 760f, 95f),
            (TrafficStateId.S4_EastWestGreen, 760f, 310f),
            (TrafficStateId.S5_EastWestLeftTurn, 550f, 310f),
            (TrafficStateId.S6_EastWestYellow, 340f, 310f),
            (TrafficStateId.S7_AllRedClearance2, 130f, 310f),
            (TrafficStateId.S8_RightTurnPhase, 235f, 202f),
            (TrafficStateId.S9_EmergencyPriority, 655f, 202f)
        };

        public StateDiagramControl(TrafficController controller)
        {
            _controller = controller;
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.FromArgb(16, 19, 24);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (Width <= 0 || Height <= 0) return;
            float scale = Math.Min(Width / 900f, Height / 410f);
            float offsetX = (Width - 900f * scale) / 2f;
            float offsetY = (Height - 410f * scale) / 2f;
            float vx = (e.X - offsetX) / scale;
            float vy = (e.Y - offsetY) / scale;

            foreach (var (id, cx, cy) in Nodes)
            {
                float dx = vx - cx;
                float dy = vy - cy;
                if (dx * dx + dy * dy <= 46f * 46f)
                {
                    _controller.SelectManualPhase(id);
                    break;
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (Width <= 0 || Height <= 0) return;
            float scale = Math.Min(Width / 900f, Height / 410f);
            float offsetX = (Width - 900f * scale) / 2f;
            float offsetY = (Height - 410f * scale) / 2f;
            g.TranslateTransform(offsetX, offsetY);
            g.ScaleTransform(scale, scale);

            using var edgePen = new Pen(Color.FromArgb(71, 85, 105), 2f) { EndCap = LineCap.ArrowAnchor };
            using var activeEdgePen = new Pen(Color.FromArgb(139, 92, 246), 3f) { EndCap = LineCap.ArrowAnchor };

            // Draw primary cycle links
            for (int i = 0; i < 8; i++)
            {
                var a = Nodes[i];
                var b = Nodes[(i + 1) % 8];
                bool isNext = _controller.CurrentState == a.Id && _controller.NextTransitionPreview.NextState == b.Id;
                g.DrawLine(isNext ? activeEdgePen : edgePen, a.Cx, a.Cy, b.Cx, b.Cy);
            }

            using var codeFont = new Font("Consolas", 11f, FontStyle.Bold);
            using var subFont = new Font("Segoe UI", 7.5f, FontStyle.Bold);

            foreach (var (id, cx, cy) in Nodes)
            {
                var meta = TrafficStateMetadata.All[id];
                bool isActive = _controller.CurrentState == id;
                bool isPredicted = _controller.NextTransitionPreview.NextState == id && !isActive;

                Color borderColor = isActive
                    ? (id == TrafficStateId.S9_EmergencyPriority ? Color.FromArgb(239, 68, 68) : Color.FromArgb(34, 197, 94))
                    : isPredicted ? Color.FromArgb(139, 92, 246) : Color.FromArgb(71, 85, 105);

                using var fillBrush = new SolidBrush(isActive ? Color.FromArgb(30, 38, 56) : Color.FromArgb(22, 28, 38));
                using var borderPen = new Pen(borderColor, isActive ? 3.5f : 1.8f);

                g.FillEllipse(fillBrush, cx - 44f, cy - 44f, 88f, 88f);
                g.DrawEllipse(borderPen, cx - 44f, cy - 44f, 88f, 88f);

                g.DrawString(meta.Code, codeFont, Brushes.White, cx - 14f, cy - 22f);
                g.DrawString(meta.ShortName, subFont, Brushes.LightGray, cx - 34f, cy - 2f);
                g.DrawString(meta.DefaultOutputSummary, subFont, isActive ? Brushes.LightGreen : Brushes.Gray, cx - 38f, cy + 14f);
            }
        }
    }
}
