using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("TrafficLightSimulator")]
[assembly: AssemblyDescription("Native C# .NET 8 Windows Forms Smart Traffic Light Intersection Simulator with Mealy Machine Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Smart Traffic Control Engineering")]
[assembly: AssemblyProduct("TrafficLightSimulator")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: SupportedOSPlatform("windows")]
