using System;
using System.Collections.Generic;
using System.Linq;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controllers
{
    public sealed class TransitionRuleRecord
    {
        public string Id { get; init; } = string.Empty;
        public TrafficStateId CurrentState { get; init; }
        public string InputCondition { get; init; } = string.Empty;
        public TrafficStateId NextState { get; init; }
        public string StandardLightOutputs { get; init; } = string.Empty;
        public string LeftArrowOutputs { get; init; } = string.Empty;
        public string RightArrowOutputs { get; init; } = string.Empty;
        public string PedestrianOutputs { get; init; } = string.Empty;
        public int Priority { get; init; }
    }

    /// <summary>
    /// Formal Mealy Finite-State Machine M = (S, Σ, Λ, δ, λ, S0).
    /// Calculates Next State δ(S, Σ) and Signal Outputs λ(S, Σ) with zero-conflict hardware interlocking.
    /// </summary>
    public sealed class MealyMachine
    {
        public static readonly IReadOnlyList<TransitionRuleRecord> TransitionTable = new List<TransitionRuleRecord>
        {
            new() { Id = "T01", CurrentState = TrafficStateId.S0_NorthSouthGreen, InputCondition = "EmergencyDetected(Any)", NextState = TrafficStateId.S2_NorthSouthYellow, StandardLightOutputs = "N/S: YELLOW, E/W: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T02", CurrentState = TrafficStateId.S0_NorthSouthGreen, InputCondition = "TimerExpired ∧ NS_LeftDemand", NextState = TrafficStateId.S1_NorthSouthLeftTurn, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "N/S: GREEN ARROW, E/W: RED", RightArrowOutputs = "N/S: GREEN (if NoPed), E/W: RED", PedestrianOutputs = "ALL: DONT WALK", Priority = 2 },
            new() { Id = "T03", CurrentState = TrafficStateId.S0_NorthSouthGreen, InputCondition = "TimerExpired ∧ ¬NS_LeftDemand", NextState = TrafficStateId.S2_NorthSouthYellow, StandardLightOutputs = "N/S: YELLOW, E/W: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 3 },
            new() { Id = "T04", CurrentState = TrafficStateId.S1_NorthSouthLeftTurn, InputCondition = "TimerExpired ∨ EmergencyDetected", NextState = TrafficStateId.S2_NorthSouthYellow, StandardLightOutputs = "N/S: YELLOW, E/W: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T05", CurrentState = TrafficStateId.S2_NorthSouthYellow, InputCondition = "TimerExpired (Yellow Clearance)", NextState = TrafficStateId.S3_AllRedClearance1, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T06", CurrentState = TrafficStateId.S3_AllRedClearance1, InputCondition = "ClearanceComplete ∧ EmergencyActive", NextState = TrafficStateId.S9_EmergencyPriority, StandardLightOutputs = "EmergencyDir: GREEN, Others: RED", LeftArrowOutputs = "EmergencyDir: GREEN ARROW", RightArrowOutputs = "EmergencyDir: GREEN ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T07", CurrentState = TrafficStateId.S3_AllRedClearance1, InputCondition = "ClearanceComplete ∧ ¬Emergency ∧ NormalFlow", NextState = TrafficStateId.S4_EastWestGreen, StandardLightOutputs = "E/W: GREEN, N/S: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "E/W: GREEN (if NoPed), N/S: RED", PedestrianOutputs = "E/W: WALK, N/S: DONT WALK", Priority = 2 },
            new() { Id = "T08", CurrentState = TrafficStateId.S4_EastWestGreen, InputCondition = "EmergencyDetected(Any)", NextState = TrafficStateId.S6_EastWestYellow, StandardLightOutputs = "E/W: YELLOW, N/S: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T09", CurrentState = TrafficStateId.S4_EastWestGreen, InputCondition = "TimerExpired ∧ EW_LeftDemand", NextState = TrafficStateId.S5_EastWestLeftTurn, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "E/W: GREEN ARROW, N/S: RED", RightArrowOutputs = "E/W: GREEN (if NoPed), N/S: RED", PedestrianOutputs = "ALL: DONT WALK", Priority = 2 },
            new() { Id = "T10", CurrentState = TrafficStateId.S4_EastWestGreen, InputCondition = "TimerExpired ∧ ¬EW_LeftDemand", NextState = TrafficStateId.S6_EastWestYellow, StandardLightOutputs = "E/W: YELLOW, N/S: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 3 },
            new() { Id = "T11", CurrentState = TrafficStateId.S5_EastWestLeftTurn, InputCondition = "TimerExpired ∨ EmergencyDetected", NextState = TrafficStateId.S6_EastWestYellow, StandardLightOutputs = "E/W: YELLOW, N/S: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T12", CurrentState = TrafficStateId.S6_EastWestYellow, InputCondition = "TimerExpired (Yellow Clearance)", NextState = TrafficStateId.S7_AllRedClearance2, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T13", CurrentState = TrafficStateId.S7_AllRedClearance2, InputCondition = "ClearanceComplete ∧ EmergencyActive", NextState = TrafficStateId.S9_EmergencyPriority, StandardLightOutputs = "EmergencyDir: GREEN, Others: RED", LeftArrowOutputs = "EmergencyDir: GREEN ARROW", RightArrowOutputs = "EmergencyDir: GREEN ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T14", CurrentState = TrafficStateId.S7_AllRedClearance2, InputCondition = "ClearanceComplete ∧ RightTurnDemand", NextState = TrafficStateId.S8_RightTurnPhase, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "NoPed Approaches: GREEN ARROW", PedestrianOutputs = "Requested Crossings: WALK", Priority = 2 },
            new() { Id = "T15", CurrentState = TrafficStateId.S7_AllRedClearance2, InputCondition = "ClearanceComplete ∧ ¬RightTurnDemand", NextState = TrafficStateId.S0_NorthSouthGreen, StandardLightOutputs = "N/S: GREEN, E/W: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "N/S: GREEN (if NoPed), E/W: RED", PedestrianOutputs = "N/S: WALK, E/W: DONT WALK", Priority = 3 },
            new() { Id = "T16", CurrentState = TrafficStateId.S8_RightTurnPhase, InputCondition = "EmergencyDetected(Any)", NextState = TrafficStateId.S9_EmergencyPriority, StandardLightOutputs = "EmergencyDir: GREEN, Others: RED", LeftArrowOutputs = "EmergencyDir: GREEN ARROW", RightArrowOutputs = "EmergencyDir: GREEN ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 },
            new() { Id = "T17", CurrentState = TrafficStateId.S8_RightTurnPhase, InputCondition = "TimerExpired ∧ EW_Congestion > NS_Congestion", NextState = TrafficStateId.S4_EastWestGreen, StandardLightOutputs = "E/W: GREEN, N/S: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "E/W: GREEN (if NoPed), N/S: RED", PedestrianOutputs = "E/W: WALK, N/S: DONT WALK", Priority = 2 },
            new() { Id = "T18", CurrentState = TrafficStateId.S8_RightTurnPhase, InputCondition = "TimerExpired ∧ NS_Congestion >= EW_Congestion", NextState = TrafficStateId.S0_NorthSouthGreen, StandardLightOutputs = "N/S: GREEN, E/W: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "N/S: GREEN (if NoPed), E/W: RED", PedestrianOutputs = "N/S: WALK, E/W: DONT WALK", Priority = 3 },
            new() { Id = "T19", CurrentState = TrafficStateId.S9_EmergencyPriority, InputCondition = "EmergencyCleared ∧ PriorityComplete", NextState = TrafficStateId.S3_AllRedClearance1, StandardLightOutputs = "ALL: RED", LeftArrowOutputs = "ALL: RED ARROW", RightArrowOutputs = "ALL: RED ARROW", PedestrianOutputs = "ALL: DONT WALK", Priority = 1 }
        };

        public static TrafficOutput ComputeMealyOutputs(TrafficStateId state, TrafficInput input)
        {
            var outVec = new TrafficOutput
            {
                PhaseDescription = TrafficStateMetadata.All[state].Description,
                MealyRuleApplied = $"λ({TrafficStateMetadata.All[state].Code}, Input)"
            };

            int nsMax = Math.Max(
                TrafficSensor.CongestionWeight(input.Sensors[Direction.North].Congestion),
                TrafficSensor.CongestionWeight(input.Sensors[Direction.South].Congestion));
            int ewMax = Math.Max(
                TrafficSensor.CongestionWeight(input.Sensors[Direction.East].Congestion),
                TrafficSensor.CongestionWeight(input.Sensors[Direction.West].Congestion));

            switch (state)
            {
                case TrafficStateId.S0_NorthSouthGreen:
                    outVec.Signals[Direction.North].StandardLight = LightColor.Green;
                    outVec.Signals[Direction.South].StandardLight = LightColor.Green;
                    outVec.Signals[Direction.North].Pedestrian = PedestrianSignal.Walk;
                    outVec.Signals[Direction.South].Pedestrian = PedestrianSignal.Walk;
                    outVec.Signals[Direction.North].RightArrow = !input.Sensors[Direction.East].PedestrianRequest ? ArrowSignal.GreenArrow : ArrowSignal.RedArrow;
                    outVec.Signals[Direction.South].RightArrow = !input.Sensors[Direction.West].PedestrianRequest ? ArrowSignal.GreenArrow : ArrowSignal.RedArrow;

                    if (nsMax >= 3 && ewMax <= 2) outVec.AdaptiveExtensionSeconds = nsMax == 4 ? 5 : 3;
                    else if (ewMax == 4 && nsMax <= 2) outVec.AdaptiveExtensionSeconds = -2;

                    outVec.ActiveGreenSummary = "North & South Straight GREEN";
                    outVec.MealyRuleApplied = outVec.AdaptiveExtensionSeconds > 0
                        ? $"λ(S0, NS={(nsMax >= 4 ? "CRITICAL" : "HIGH")}) → N/S Green +{outVec.AdaptiveExtensionSeconds}s Extension"
                        : "λ(S0, Standard) → N/S Straight Green + Walk N/S";
                    break;

                case TrafficStateId.S1_NorthSouthLeftTurn:
                    outVec.Signals[Direction.North].LeftArrow = ArrowSignal.GreenArrow;
                    outVec.Signals[Direction.South].LeftArrow = ArrowSignal.GreenArrow;
                    if (input.Sensors[Direction.North].RightTurnDemand && !input.Sensors[Direction.North].PedestrianRequest)
                        outVec.Signals[Direction.North].RightArrow = ArrowSignal.GreenArrow;
                    if (input.Sensors[Direction.South].RightTurnDemand && !input.Sensors[Direction.South].PedestrianRequest)
                        outVec.Signals[Direction.South].RightArrow = ArrowSignal.GreenArrow;

                    if (nsMax >= 3) outVec.AdaptiveExtensionSeconds = 2;
                    outVec.ActiveGreenSummary = "North & South Protected Left Arrow GREEN";
                    outVec.MealyRuleApplied = "λ(S1, NS_LeftDemand=True) → Protected Left Arrows GREEN, Ped DONT WALK";
                    break;

                case TrafficStateId.S2_NorthSouthYellow:
                    outVec.Signals[Direction.North].StandardLight = LightColor.Yellow;
                    outVec.Signals[Direction.South].StandardLight = LightColor.Yellow;
                    outVec.ActiveGreenSummary = "North & South YELLOW Transition";
                    outVec.MealyRuleApplied = input.EmergencyActive
                        ? "λ(S2, EmergencyPreempt) → Immediate Yellow Clearance"
                        : "λ(S2, TimerExpired) → N/S Yellow Warning";
                    break;

                case TrafficStateId.S3_AllRedClearance1:
                    outVec.ActiveGreenSummary = "ALL RED Clearance (N/S → E/W)";
                    outVec.MealyRuleApplied = "λ(S3, SafetyInterlock) → All Signals RED";
                    break;

                case TrafficStateId.S4_EastWestGreen:
                    outVec.Signals[Direction.East].StandardLight = LightColor.Green;
                    outVec.Signals[Direction.West].StandardLight = LightColor.Green;
                    outVec.Signals[Direction.East].Pedestrian = PedestrianSignal.Walk;
                    outVec.Signals[Direction.West].Pedestrian = PedestrianSignal.Walk;
                    outVec.Signals[Direction.East].RightArrow = !input.Sensors[Direction.South].PedestrianRequest ? ArrowSignal.GreenArrow : ArrowSignal.RedArrow;
                    outVec.Signals[Direction.West].RightArrow = !input.Sensors[Direction.North].PedestrianRequest ? ArrowSignal.GreenArrow : ArrowSignal.RedArrow;

                    if (ewMax >= 3 && nsMax <= 2) outVec.AdaptiveExtensionSeconds = ewMax == 4 ? 5 : 3;
                    else if (nsMax == 4 && ewMax <= 2) outVec.AdaptiveExtensionSeconds = -2;

                    outVec.ActiveGreenSummary = "East & West Straight GREEN";
                    outVec.MealyRuleApplied = outVec.AdaptiveExtensionSeconds > 0
                        ? $"λ(S4, EW={(ewMax >= 4 ? "CRITICAL" : "HIGH")}) → E/W Green +{outVec.AdaptiveExtensionSeconds}s Extension"
                        : "λ(S4, Standard) → E/W Straight Green + Walk E/W";
                    break;

                case TrafficStateId.S5_EastWestLeftTurn:
                    outVec.Signals[Direction.East].LeftArrow = ArrowSignal.GreenArrow;
                    outVec.Signals[Direction.West].LeftArrow = ArrowSignal.GreenArrow;
                    if (input.Sensors[Direction.East].RightTurnDemand && !input.Sensors[Direction.East].PedestrianRequest)
                        outVec.Signals[Direction.East].RightArrow = ArrowSignal.GreenArrow;
                    if (input.Sensors[Direction.West].RightTurnDemand && !input.Sensors[Direction.West].PedestrianRequest)
                        outVec.Signals[Direction.West].RightArrow = ArrowSignal.GreenArrow;

                    if (ewMax >= 3) outVec.AdaptiveExtensionSeconds = 2;
                    outVec.ActiveGreenSummary = "East & West Protected Left Arrow GREEN";
                    outVec.MealyRuleApplied = "λ(S5, EW_LeftDemand=True) → Protected E/W Left Arrows GREEN";
                    break;

                case TrafficStateId.S6_EastWestYellow:
                    outVec.Signals[Direction.East].StandardLight = LightColor.Yellow;
                    outVec.Signals[Direction.West].StandardLight = LightColor.Yellow;
                    outVec.ActiveGreenSummary = "East & West YELLOW Transition";
                    outVec.MealyRuleApplied = input.EmergencyActive
                        ? "λ(S6, EmergencyPreempt) → Immediate Yellow Clearance"
                        : "λ(S6, TimerExpired) → E/W Yellow Warning";
                    break;

                case TrafficStateId.S7_AllRedClearance2:
                    outVec.ActiveGreenSummary = "ALL RED Clearance (E/W → Next Phase)";
                    outVec.MealyRuleApplied = "λ(S7, SafetyInterlock) → All Signals RED";
                    break;

                case TrafficStateId.S8_RightTurnPhase:
                    var activeRightDirs = new List<string>();
                    foreach (Direction dir in Enum.GetValues(typeof(Direction)))
                    {
                        if (input.Sensors[dir].PedestrianRequest)
                        {
                            outVec.Signals[dir].Pedestrian = PedestrianSignal.Walk;
                            outVec.Signals[dir].RightArrow = ArrowSignal.RedArrow;
                        }
                        else
                        {
                            outVec.Signals[dir].Pedestrian = PedestrianSignal.DontWalk;
                            outVec.Signals[dir].RightArrow = ArrowSignal.GreenArrow;
                            activeRightDirs.Add(dir.ToString());
                        }
                    }
                    outVec.ActiveGreenSummary = activeRightDirs.Count > 0
                        ? $"Right-Turn Green Arrows ({string.Join(", ", activeRightDirs)})"
                        : "Protected All-Way Pedestrian Walk";
                    outVec.MealyRuleApplied = "λ(S8, RightTurn + PedFilter) → Non-Conflicting Right Arrows GREEN";
                    break;

                case TrafficStateId.S9_EmergencyPriority:
                    Direction emDir = input.EmergencyDirection ?? Direction.North;
                    outVec.Signals[emDir].StandardLight = LightColor.Green;
                    outVec.Signals[emDir].LeftArrow = ArrowSignal.GreenArrow;
                    outVec.Signals[emDir].RightArrow = ArrowSignal.GreenArrow;
                    outVec.ActiveGreenSummary = $"EMERGENCY CORRIDOR GREEN: {emDir}";
                    outVec.PhaseDescription = $"Priority preemption active for {emDir}bound emergency responder. All conflicting approaches held RED.";
                    outVec.MealyRuleApplied = $"λ(S9, Emergency={emDir}) → {emDir} Full Green Corridor, All Others RED";
                    break;
            }

            bool nsHasGreen = outVec.Signals[Direction.North].IsGreen ||
                              outVec.Signals[Direction.South].IsGreen ||
                              outVec.Signals[Direction.North].IsLeftGreen ||
                              outVec.Signals[Direction.South].IsLeftGreen;
            bool ewHasGreen = outVec.Signals[Direction.East].IsGreen ||
                              outVec.Signals[Direction.West].IsGreen ||
                              outVec.Signals[Direction.East].IsLeftGreen ||
                              outVec.Signals[Direction.West].IsLeftGreen;

            outVec.ConflictSafetyVerified = !(nsHasGreen && ewHasGreen);
            return outVec;
        }

        public static (TrafficStateId NextState, string TransitionReason, string RuleId) EvaluateTransition(
            TrafficStateId currentState,
            TrafficInput input)
        {
            if (input.EmergencyActive && currentState != TrafficStateId.S9_EmergencyPriority)
            {
                if (currentState == TrafficStateId.S0_NorthSouthGreen || currentState == TrafficStateId.S1_NorthSouthLeftTurn)
                    return (TrafficStateId.S2_NorthSouthYellow, $"Emergency Vehicle Detected ({input.EmergencyDirection}) → Safe N/S Yellow Clearance", "T01");
                if (currentState == TrafficStateId.S4_EastWestGreen || currentState == TrafficStateId.S5_EastWestLeftTurn)
                    return (TrafficStateId.S6_EastWestYellow, $"Emergency Vehicle Detected ({input.EmergencyDirection}) → Safe E/W Yellow Clearance", "T08");
                if (currentState == TrafficStateId.S2_NorthSouthYellow)
                    return (TrafficStateId.S3_AllRedClearance1, "Emergency Preemption → All-Red Clearance", "T05");
                if (currentState == TrafficStateId.S6_EastWestYellow)
                    return (TrafficStateId.S7_AllRedClearance2, "Emergency Preemption → All-Red Clearance", "T12");

                return (TrafficStateId.S9_EmergencyPriority, $"Clearance Complete → Activating Emergency Priority ({input.EmergencyDirection})",
                    currentState == TrafficStateId.S3_AllRedClearance1 ? "T06" : "T13");
            }

            int nsWeight = TrafficSensor.CongestionWeight(input.Sensors[Direction.North].Congestion) +
                           TrafficSensor.CongestionWeight(input.Sensors[Direction.South].Congestion);
            int ewWeight = TrafficSensor.CongestionWeight(input.Sensors[Direction.East].Congestion) +
                           TrafficSensor.CongestionWeight(input.Sensors[Direction.West].Congestion);

            return currentState switch
            {
                TrafficStateId.S0_NorthSouthGreen => input.HasNorthSouthLeftDemand
                    ? (TrafficStateId.S1_NorthSouthLeftTurn, "TimerExpired ∧ NS_LeftTurnDemand → S1 (N/S Left Turn)", "T02")
                    : (TrafficStateId.S2_NorthSouthYellow, "TimerExpired ∧ ¬NS_LeftTurnDemand → S2 (N/S Yellow)", "T03"),

                TrafficStateId.S1_NorthSouthLeftTurn =>
                    (TrafficStateId.S2_NorthSouthYellow, "TimerExpired → S2 (N/S Yellow Clearance)", "T04"),

                TrafficStateId.S2_NorthSouthYellow =>
                    (TrafficStateId.S3_AllRedClearance1, "Yellow Complete → S3 (All-Red Clearance 1)", "T05"),

                TrafficStateId.S3_AllRedClearance1 =>
                    (TrafficStateId.S4_EastWestGreen, "ClearanceComplete → S4 (East/West Green)", "T07"),

                TrafficStateId.S4_EastWestGreen => input.HasEastWestLeftDemand
                    ? (TrafficStateId.S5_EastWestLeftTurn, "TimerExpired ∧ EW_LeftTurnDemand → S5 (E/W Left Turn)", "T09")
                    : (TrafficStateId.S6_EastWestYellow, "TimerExpired ∧ ¬EW_LeftTurnDemand → S6 (E/W Yellow)", "T10"),

                TrafficStateId.S5_EastWestLeftTurn =>
                    (TrafficStateId.S6_EastWestYellow, "TimerExpired → S6 (E/W Yellow Clearance)", "T11"),

                TrafficStateId.S6_EastWestYellow =>
                    (TrafficStateId.S7_AllRedClearance2, "Yellow Complete → S7 (All-Red Clearance 2)", "T12"),

                TrafficStateId.S7_AllRedClearance2 => (input.HasAnyRightTurnDemand || input.HasAnyPedestrianRequest)
                    ? (TrafficStateId.S8_RightTurnPhase, "ClearanceComplete ∧ (RightTurnDemand ∨ PedRequest) → S8 (Right Turn / Ped Phase)", "T14")
                    : ewWeight >= nsWeight + 3
                        ? (TrafficStateId.S4_EastWestGreen, "ClearanceComplete ∧ EW_CriticalCongestion → Priority Return to S4 (E/W Green)", "T07")
                        : (TrafficStateId.S0_NorthSouthGreen, "ClearanceComplete → S0 (North/South Green)", "T15"),

                TrafficStateId.S8_RightTurnPhase => ewWeight > nsWeight + 1
                    ? (TrafficStateId.S4_EastWestGreen, "TimerExpired ∧ (EW_Congestion > NS_Congestion) → S4 (E/W Priority Green)", "T17")
                    : (TrafficStateId.S0_NorthSouthGreen, "TimerExpired ∧ (NS_Congestion ≥ EW_Congestion) → S0 (N/S Green)", "T18"),

                TrafficStateId.S9_EmergencyPriority => input.EmergencyActive
                    ? (TrafficStateId.S9_EmergencyPriority, $"Holding S9 while Emergency ({input.EmergencyDirection}) remains active", "T19")
                    : (TrafficStateId.S3_AllRedClearance1, "Emergency Cleared → S3 (All-Red Safe Recovery)", "T19"),

                _ => (TrafficStateId.S0_NorthSouthGreen, "Recovery → S0", "T15")
            };
        }

        public static TrafficOutput ApplyInteractiveOverrides(
            TrafficOutput baseOutput,
            IReadOnlyDictionary<Direction, ManualLampOverride> overrides)
        {
            if (overrides.Values.All(o => !o.HasAny))
                return baseOutput;

            var merged = baseOutput.Clone();
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                var ov = overrides[dir];
                if (ov.StandardLight.HasValue) merged.Signals[dir].StandardLight = ov.StandardLight.Value;
                if (ov.LeftArrow.HasValue) merged.Signals[dir].LeftArrow = ov.LeftArrow.Value;
                if (ov.RightArrow.HasValue) merged.Signals[dir].RightArrow = ov.RightArrow.Value;
                if (ov.Pedestrian.HasValue) merged.Signals[dir].Pedestrian = ov.Pedestrian.Value;
            }

            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                if (merged.Signals[dir].IsWalk && overrides[dir].RightArrow != ArrowSignal.GreenArrow)
                {
                    merged.Signals[dir].RightArrow = ArrowSignal.RedArrow;
                }
            }

            merged.MealyRuleApplied = $"{baseOutput.MealyRuleApplied} + Interactive Lamp Control";
            return merged;
        }
    }
}
