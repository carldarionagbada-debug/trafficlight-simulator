using System;
using System.Collections.Generic;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controllers
{
    public sealed class TrafficAnalytics
    {
        public int TotalVehiclesProcessed { get; private set; }
        public Dictionary<Direction, int> ProcessedByDirection { get; } = new();
        public Dictionary<TrafficStateId, int> StateVisitCounts { get; } = new();
        public int PedestrianCrossingsServed { get; private set; }
        public int EmergencyInterventions { get; private set; }
        public int ConflictChecksPassed { get; private set; } = 1;
        public double MaxWaitTimeSeconds { get; private set; }
        private double _cumulativeWaitSeconds;

        public TrafficAnalytics()
        {
            Reset();
        }

        public double AverageWaitTimeSeconds =>
            TotalVehiclesProcessed > 0 ? _cumulativeWaitSeconds / TotalVehiclesProcessed : 0.0;

        public void RecordCompletedVehicle(Direction origin, double waitSeconds)
        {
            TotalVehiclesProcessed++;
            ProcessedByDirection[origin]++;
            _cumulativeWaitSeconds += waitSeconds;
            if (waitSeconds > MaxWaitTimeSeconds) MaxWaitTimeSeconds = waitSeconds;
        }

        public void RecordStateTransition(TrafficStateId newState)
        {
            StateVisitCounts[newState] = StateVisitCounts.GetValueOrDefault(newState, 0) + 1;
            ConflictChecksPassed++;
        }

        public void RecordPedestrianServed(int count = 1) => PedestrianCrossingsServed += count;
        public void RecordEmergencyIntervention() => EmergencyInterventions++;

        public void Reset()
        {
            TotalVehiclesProcessed = 0;
            _cumulativeWaitSeconds = 0;
            MaxWaitTimeSeconds = 0;
            PedestrianCrossingsServed = 0;
            EmergencyInterventions = 0;
            ConflictChecksPassed = 1;

            foreach (Direction d in Enum.GetValues(typeof(Direction)))
                ProcessedByDirection[d] = 0;

            foreach (TrafficStateId st in Enum.GetValues(typeof(TrafficStateId)))
                StateVisitCounts[st] = st == TrafficStateId.S0_NorthSouthGreen ? 1 : 0;
        }
    }
}
