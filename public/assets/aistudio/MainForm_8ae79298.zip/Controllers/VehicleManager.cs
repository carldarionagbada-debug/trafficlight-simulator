using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controllers
{
    public sealed class VehicleManager
    {
        private readonly List<Vehicle> _vehicles = new();
        private readonly Random _rng = new(42);
        private float _spawnAccumulator;

        private static readonly Color[] Palette =
        {
            Color.FromArgb(59, 130, 246),  // Electric Blue
            Color.FromArgb(139, 92, 246),  // Violet
            Color.FromArgb(16, 185, 129),  // Emerald
            Color.FromArgb(245, 158, 11),  // Amber
            Color.FromArgb(236, 72, 153),  // Rose
            Color.FromArgb(226, 232, 240)  // Silver
        };

        public IReadOnlyList<Vehicle> Vehicles => _vehicles;

        public VehicleManager()
        {
            SeedInitialVehicles();
        }

        public void SeedInitialVehicles()
        {
            _vehicles.Clear();
            _vehicles.Add(new Vehicle(Direction.North, LaneType.Straight, Palette[0]) { Progress = 0.22f });
            _vehicles.Add(new Vehicle(Direction.North, LaneType.LeftTurn, Palette[1]) { Progress = 0.26f, Speed = 0f });
            _vehicles.Add(new Vehicle(Direction.South, LaneType.Straight, Palette[2]) { Progress = 0.18f });
            _vehicles.Add(new Vehicle(Direction.East, LaneType.Straight, Palette[3]) { Progress = 0.28f, Speed = 0f });
            _vehicles.Add(new Vehicle(Direction.West, LaneType.RightTurn, Palette[4]) { Progress = 0.27f, Speed = 0f });
        }

        public void SpawnEmergencyResponder(Direction direction)
        {
            _vehicles.Add(new Vehicle(direction, LaneType.Straight, Color.White, isEmergency: true)
            {
                Progress = 0.02f
            });
        }

        public void UpdateStep(
            float dt,
            TrafficInput input,
            TrafficOutput output,
            TrafficAnalytics analytics)
        {
            _spawnAccumulator += dt;
            if (_spawnAccumulator >= 0.45f)
            {
                _spawnAccumulator = 0f;
                SpawnVehiclesByDensity(input);
            }

            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                foreach (LaneType lane in Enum.GetValues(typeof(LaneType)))
                {
                    var laneCars = _vehicles
                        .Where(v => v.Origin == dir && v.Lane == lane)
                        .OrderByDescending(v => v.Progress)
                        .ToList();

                    bool greenAllowed = CanLaneProceed(output.Signals[dir], lane);

                    for (int i = 0; i < laneCars.Count; i++)
                    {
                        float? leader = i > 0 ? laneCars[i - 1].Progress : null;
                        laneCars[i].StepKinematics(dt, greenAllowed, leader);
                    }
                }
            }

            for (int i = _vehicles.Count - 1; i >= 0; i--)
            {
                if (_vehicles[i].Progress >= 1.0f)
                {
                    analytics.RecordCompletedVehicle(_vehicles[i].Origin, _vehicles[i].WaitTimeSeconds);
                    _vehicles.RemoveAt(i);
                }
            }
        }

        private void SpawnVehiclesByDensity(TrafficInput input)
        {
            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                var sensor = input.Sensors[dir];
                double chance = (sensor.DensityPercent / 100.0) * 0.48;
                if (_rng.NextDouble() > chance) continue;

                var lanes = new List<LaneType> { LaneType.Straight };
                if (sensor.LeftTurnDemand) lanes.Add(LaneType.LeftTurn);
                if (sensor.RightTurnDemand) lanes.Add(LaneType.RightTurn);
                LaneType lane = lanes[_rng.Next(lanes.Count)];

                bool blocked = _vehicles.Any(v => v.Origin == dir && v.Lane == lane && v.Progress < 0.095f);
                int dirCount = _vehicles.Count(v => v.Origin == dir);

                if (!blocked && dirCount < 14)
                {
                    _vehicles.Add(new Vehicle(dir, lane, Palette[_rng.Next(Palette.Length)]));
                }
            }
        }

        public static bool CanLaneProceed(TrafficSignal sig, LaneType lane) => lane switch
        {
            LaneType.Straight => sig.IsGreen,
            LaneType.LeftTurn => sig.IsLeftGreen,
            LaneType.RightTurn => sig.IsRightGreen || (sig.IsGreen && !sig.IsWalk),
            _ => false
        };

        public int CountByDirection(Direction direction) => _vehicles.Count(v => v.Origin == direction);
    }
}
