using System;
using System.Collections.Generic;
using System.Linq;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Controllers
{
    public sealed class LogEventRecord
    {
        public string Timestamp { get; init; } = string.Empty;
        public string Category { get; init; } = "STATE";
        public string Message { get; init; } = string.Empty;
        public TrafficStateId StateId { get; init; }

        public override string ToString() =>
            $"[{Timestamp}] [{Category,-10}] {Message} ({TrafficStateMetadata.All[StateId].Code})";
    }

    /// <summary>
    /// Centralized traffic signal controller coordinating sensors, Mealy Machine transitions,
    /// interactive lamp/arrow click overrides, vehicle simulation, analytics, and event history.
    /// </summary>
    public sealed class TrafficController
    {
        public TrafficStateId CurrentState { get; private set; } = TrafficStateId.S0_NorthSouthGreen;
        public TrafficStateId? QueuedManualState { get; private set; }
        public Dictionary<Direction, TrafficSensor> Sensors { get; } = new();
        public Dictionary<Direction, ManualLampOverride> LampOverrides { get; } = new();
        public VehicleManager VehicleManager { get; } = new();
        public TrafficAnalytics Analytics { get; } = new();
        public List<LogEventRecord> Logs { get; } = new();

        public bool IsRunning { get; private set; } = true;
        public bool IsAutoMode { get; set; } = true;
        public bool EmergencyActive { get; private set; }
        public Direction? EmergencyDirection { get; private set; }

        public double PhaseElapsedSeconds { get; private set; }
        public double SimulationSeconds { get; private set; }

        public TrafficInput CurrentInput { get; private set; } = new();
        public TrafficOutput CurrentOutput { get; private set; } = new();
        public (TrafficStateId NextState, string Reason, string RuleId) NextTransitionPreview { get; private set; }

        public event EventHandler? SimulationUpdated;
        public event EventHandler<LogEventRecord>? LogRecorded;

        public TrafficController()
        {
            Sensors[Direction.North] = new TrafficSensor(Direction.North, 45);
            Sensors[Direction.South] = new TrafficSensor(Direction.South, 40);
            Sensors[Direction.East] = new TrafficSensor(Direction.East, 30);
            Sensors[Direction.West] = new TrafficSensor(Direction.West, 25);

            foreach (Direction d in Enum.GetValues(typeof(Direction)))
            {
                LampOverrides[d] = new ManualLampOverride();
            }

            RecalculateMealyState();
            AppendLog("STATE", "Simulation Started in S0 (NORTH/SOUTH GREEN). Mealy Machine active.");
        }

        public void Start()
        {
            IsRunning = true;
            AppendLog("STATE", "Simulation Started.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void Pause()
        {
            IsRunning = false;
            AppendLog("STATE", "Simulation Paused.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void Resume()
        {
            IsRunning = true;
            AppendLog("STATE", "Simulation Resumed.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void Reset()
        {
            IsRunning = false;
            IsAutoMode = true;
            CurrentState = TrafficStateId.S0_NorthSouthGreen;
            QueuedManualState = null;
            PhaseElapsedSeconds = 0;
            SimulationSeconds = 0;
            EmergencyActive = false;
            EmergencyDirection = null;

            Sensors[Direction.North].DensityPercent = 45;
            Sensors[Direction.South].DensityPercent = 40;
            Sensors[Direction.East].DensityPercent = 30;
            Sensors[Direction.West].DensityPercent = 25;

            foreach (var s in Sensors.Values)
            {
                s.LeftTurnDemand = true;
                s.RightTurnDemand = true;
                s.PedestrianRequest = false;
            }
            ClearLampOverrides(silent: true);
            VehicleManager.SeedInitialVehicles();
            Analytics.Reset();
            RecalculateMealyState();
            AppendLog("STATE", "Simulation Reset to S0 (NORTH/SOUTH GREEN).");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void Tick(float dt)
        {
            if (!IsRunning) return;

            SimulationSeconds += dt;
            PhaseElapsedSeconds += dt;
            RecalculateMealyState();
            VehicleManager.UpdateStep(dt, CurrentInput, CurrentOutput, Analytics);

            if (IsAutoMode && PhaseElapsedSeconds >= CurrentInput.TargetPhaseDurationSeconds)
            {
                StepNextState();
            }
            else
            {
                SimulationUpdated?.Invoke(this, EventArgs.Empty);
            }
        }

        public void StepNextState(string? explicitReason = null)
        {
            TrafficStateId nextState = NextTransitionPreview.NextState;
            string reason = explicitReason ?? NextTransitionPreview.Reason;

            if (QueuedManualState.HasValue &&
                (CurrentState == TrafficStateId.S3_AllRedClearance1 || CurrentState == TrafficStateId.S7_AllRedClearance2))
            {
                nextState = QueuedManualState.Value;
                reason = $"Safety Clearance Complete → Activating Manual Target {TrafficStateMetadata.All[nextState].Code}";
                QueuedManualState = null;
            }

            foreach (Direction dir in Enum.GetValues(typeof(Direction)))
            {
                if (CurrentOutput.Signals[dir].IsWalk && Sensors[dir].PedestrianRequest)
                {
                    Sensors[dir].PedestrianRequest = false;
                    Analytics.RecordPedestrianServed();
                    AppendLog("PEDESTRIAN", $"Pedestrian WALK completed safely for {dir}.");
                }
            }

            TrafficStateId previous = CurrentState;
            CurrentState = nextState;
            PhaseElapsedSeconds = 0;
            ClearLampOverrides(silent: true);
            Analytics.RecordStateTransition(nextState);
            RecalculateMealyState();

            AppendLog("STATE", $"State changed: {TrafficStateMetadata.All[previous].Code} → {TrafficStateMetadata.All[nextState].Code} ({TrafficStateMetadata.All[nextState].Name}) [{reason}]");
            AppendLog("SIGNAL", $"Outputs Updated: {CurrentOutput.ActiveGreenSummary}");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void SetTrafficDensity(Direction direction, int percent)
        {
            Sensors[direction].DensityPercent = percent;
            RecalculateMealyState();
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ToggleTurnDemand(Direction direction, bool isLeft)
        {
            if (isLeft) Sensors[direction].LeftTurnDemand = !Sensors[direction].LeftTurnDemand;
            else Sensors[direction].RightTurnDemand = !Sensors[direction].RightTurnDemand;
            RecalculateMealyState();
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void RequestPedestrianCrossing(Direction direction)
        {
            Sensors[direction].PedestrianRequest = true;
            RecalculateMealyState();
            AppendLog("PEDESTRIAN", $"Pedestrian Crossing Requested: {direction}. Registered for safe WALK phase.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void TriggerEmergency(Direction direction)
        {
            EmergencyActive = true;
            EmergencyDirection = direction;
            Analytics.RecordEmergencyIntervention();
            VehicleManager.SpawnEmergencyResponder(direction);
            AppendLog("EMERGENCY", $"Emergency Vehicle Detected: {direction}. Transitioning safely to S9 (EMERGENCY PRIORITY).");

            if (CurrentState != TrafficStateId.S9_EmergencyPriority)
            {
                if (CurrentState == TrafficStateId.S0_NorthSouthGreen || CurrentState == TrafficStateId.S1_NorthSouthLeftTurn)
                    CurrentState = TrafficStateId.S2_NorthSouthYellow;
                else if (CurrentState == TrafficStateId.S4_EastWestGreen || CurrentState == TrafficStateId.S5_EastWestLeftTurn)
                    CurrentState = TrafficStateId.S6_EastWestYellow;
                else
                    CurrentState = TrafficStateId.S9_EmergencyPriority;

                PhaseElapsedSeconds = 0;
            }
            RecalculateMealyState();
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ClearEmergency()
        {
            if (!EmergencyActive) return;
            EmergencyActive = false;
            EmergencyDirection = null;
            AppendLog("EMERGENCY", "Emergency Priority Cleared. Transitioning through S3 (ALL RED CLEARANCE) to normal flow.");
            if (CurrentState == TrafficStateId.S9_EmergencyPriority)
            {
                CurrentState = TrafficStateId.S3_AllRedClearance1;
                PhaseElapsedSeconds = 0;
            }
            RecalculateMealyState();
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void SelectManualPhase(TrafficStateId requested)
        {
            bool currNS = CurrentState == TrafficStateId.S0_NorthSouthGreen || CurrentState == TrafficStateId.S1_NorthSouthLeftTurn;
            bool currEW = CurrentState == TrafficStateId.S4_EastWestGreen || CurrentState == TrafficStateId.S5_EastWestLeftTurn;
            bool targNS = requested == TrafficStateId.S0_NorthSouthGreen || requested == TrafficStateId.S1_NorthSouthLeftTurn;
            bool targEW = requested == TrafficStateId.S4_EastWestGreen || requested == TrafficStateId.S5_EastWestLeftTurn;

            if (currNS && targEW)
            {
                CurrentState = TrafficStateId.S2_NorthSouthYellow;
                QueuedManualState = requested;
                AppendLog("STATE", $"Safety Interlock: Routing N/S Green through S2 (Yellow) → S3 (All-Red) before {requested}.");
            }
            else if (currEW && targNS)
            {
                CurrentState = TrafficStateId.S6_EastWestYellow;
                QueuedManualState = requested;
                AppendLog("STATE", $"Safety Interlock: Routing E/W Green through S6 (Yellow) → S7 (All-Red) before {requested}.");
            }
            else
            {
                CurrentState = requested;
                QueuedManualState = null;
                AppendLog("STATE", $"Manual Phase Applied: {TrafficStateMetadata.All[requested].Code} ({TrafficStateMetadata.All[requested].Name}).");
            }

            PhaseElapsedSeconds = 0;
            ClearLampOverrides(silent: true);
            RecalculateMealyState();
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ClickStandardLamp(Direction dir, LightColor color)
        {
            LampOverrides[dir].StandardLight = color;
            if (color == LightColor.Green)
            {
                var conflicting = (dir == Direction.North || dir == Direction.South)
                    ? new[] { Direction.East, Direction.West }
                    : new[] { Direction.North, Direction.South };
                foreach (var cDir in conflicting)
                {
                    LampOverrides[cDir].StandardLight = LightColor.Red;
                    LampOverrides[cDir].LeftArrow = ArrowSignal.RedArrow;
                }
            }
            RecalculateMealyState();
            AppendLog("SIGNAL", $"Interactive Signal Control: {dir} Main Light set to {color}.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ToggleLeftArrow(Direction dir, ArrowSignal? explicitState = null)
        {
            ArrowSignal current = CurrentOutput.Signals[dir].LeftArrow;
            ArrowSignal target = explicitState ?? (current == ArrowSignal.GreenArrow ? ArrowSignal.RedArrow : ArrowSignal.GreenArrow);
            LampOverrides[dir].LeftArrow = target;

            if (target == ArrowSignal.GreenArrow)
            {
                Sensors[dir].LeftTurnDemand = true;
                var conflicting = (dir == Direction.North || dir == Direction.South)
                    ? new[] { Direction.East, Direction.West }
                    : new[] { Direction.North, Direction.South };
                foreach (var cDir in conflicting)
                {
                    LampOverrides[cDir].StandardLight = LightColor.Red;
                    LampOverrides[cDir].LeftArrow = ArrowSignal.RedArrow;
                }
            }
            RecalculateMealyState();
            AppendLog("SIGNAL", $"Interactive Turn Control: {dir} Left-Turn Arrow set to {target}.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ToggleRightArrow(Direction dir, ArrowSignal? explicitState = null)
        {
            ArrowSignal current = CurrentOutput.Signals[dir].RightArrow;
            ArrowSignal target = explicitState ?? (current == ArrowSignal.GreenArrow ? ArrowSignal.RedArrow : ArrowSignal.GreenArrow);
            LampOverrides[dir].RightArrow = target;
            if (target == ArrowSignal.GreenArrow)
            {
                Sensors[dir].RightTurnDemand = true;
                LampOverrides[dir].Pedestrian = PedestrianSignal.DontWalk;
            }
            RecalculateMealyState();
            AppendLog("SIGNAL", $"Interactive Turn Control: {dir} Right-Turn Arrow set to {target}.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void TogglePedestrianWalk(Direction dir)
        {
            PedestrianSignal next = CurrentOutput.Signals[dir].IsWalk ? PedestrianSignal.DontWalk : PedestrianSignal.Walk;
            LampOverrides[dir].Pedestrian = next;
            if (next == PedestrianSignal.Walk)
            {
                LampOverrides[dir].RightArrow = ArrowSignal.RedArrow;
            }
            RecalculateMealyState();
            AppendLog("PEDESTRIAN", $"Interactive Pedestrian Signal: {dir} set to {next}.");
            SimulationUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void ClearLampOverrides(bool silent = false)
        {
            foreach (var ov in LampOverrides.Values) ov.Clear();
            if (!silent)
            {
                RecalculateMealyState();
                AppendLog("SIGNAL", "Synced all traffic signals to Mealy Machine output.");
                SimulationUpdated?.Invoke(this, EventArgs.Empty);
            }
        }

        public void RecalculateMealyState()
        {
            double baseSec = TrafficStateMetadata.All[CurrentState].BaseDurationSeconds;
            var input = new TrafficInput
            {
                EmergencyActive = EmergencyActive,
                EmergencyDirection = EmergencyDirection,
                IsAutoMode = IsAutoMode,
                ManualOverrideState = QueuedManualState,
                PhaseElapsedSeconds = PhaseElapsedSeconds,
                TargetPhaseDurationSeconds = baseSec
            };

            foreach (Direction d in Enum.GetValues(typeof(Direction)))
            {
                Sensors[d].VehicleCount = VehicleManager.CountByDirection(d);
                input.Sensors[d] = Sensors[d].ToSnapshot();
            }

            var baseOut = MealyMachine.ComputeMealyOutputs(CurrentState, input);
            double targetSec = Math.Max(2.0, baseSec + baseOut.AdaptiveExtensionSeconds);
            input.TargetPhaseDurationSeconds = targetSec;
            input.TimerExpired = PhaseElapsedSeconds >= targetSec;

            CurrentInput = input;
            CurrentOutput = MealyMachine.ApplyInteractiveOverrides(baseOut, LampOverrides);
            NextTransitionPreview = MealyMachine.EvaluateTransition(CurrentState, input);
        }

        public void AppendLog(string category, string message)
        {
            var rec = new LogEventRecord
            {
                Timestamp = DateTime.Now.ToString("HH:mm:ss"),
                Category = category,
                Message = message,
                StateId = CurrentState
            };
            Logs.Insert(0, rec);
            if (Logs.Count > 200) Logs.RemoveAt(Logs.Count - 1);
            LogRecorded?.Invoke(this, rec);
        }
    }
}
