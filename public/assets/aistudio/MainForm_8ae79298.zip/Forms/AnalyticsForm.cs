using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Forms
{
    /// <summary>
    /// Displays live directional traffic throughput, congestion metrics, waiting times,
    /// and state activation counts.
    /// </summary>
    public sealed class AnalyticsForm : Panel
    {
        private readonly TrafficController _controller;
        private readonly TextBox _analyticsReportLabel;

        public AnalyticsForm(TrafficController controller)
        {
            _controller = controller;
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(16, 19, 24);
            Padding = new Padding(18);

            _analyticsReportLabel = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                WordWrap = false,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Cascadia Mono", 9.5f),
                ForeColor = Color.FromArgb(226, 232, 240),
                BackColor = Color.FromArgb(20, 28, 40),
                BorderStyle = BorderStyle.None,
                HideSelection = false,
                TabStop = true
            };

            Controls.Add(_analyticsReportLabel);
            _controller.SimulationUpdated += (_, _) => RefreshMetrics();
            RefreshMetrics();
        }

        public void RefreshMetrics()
        {
            var a = _controller.Analytics;
            var sb = new StringBuilder();
            sb.AppendLine("=== SMART TRAFFIC INTERSECTION ANALYTICS & PERFORMANCE MONITOR ===");
            sb.AppendLine();
            sb.AppendLine($"Total Simulation Uptime   : {_controller.SimulationSeconds:0.1} seconds");
            sb.AppendLine($"Total Vehicles Processed  : {a.TotalVehiclesProcessed}");
            sb.AppendLine($"Average Vehicle Wait Time : {a.AverageWaitTimeSeconds:0.2} seconds");
            sb.AppendLine($"Peak Vehicle Wait Time    : {a.MaxWaitTimeSeconds:0.2} seconds");
            sb.AppendLine($"Pedestrian Walks Served   : {a.PedestrianCrossingsServed}");
            sb.AppendLine($"Emergency Preemptions     : {a.EmergencyInterventions}");
            sb.AppendLine($"Conflict Safety Checks    : {a.ConflictChecksPassed} (ZERO CONFLICTS)");
            sb.AppendLine();
            sb.AppendLine("--- APPROACH BREAKDOWN ---");
            foreach (Direction d in Enum.GetValues(typeof(Direction)))
            {
                var s = _controller.Sensors[d];
                sb.AppendLine($"{d,-8} | Density: {s.DensityPercent,3}% ({s.Congestion,-8}) | Active Queue: {s.VehicleCount,2} | Processed: {a.ProcessedByDirection[d],4} | L-Turn:{(s.LeftTurnDemand ? "ON " : "OFF")} R-Turn:{(s.RightTurnDemand ? "ON " : "OFF")}");
            }
            sb.AppendLine();
            sb.AppendLine("--- MEALY STATE VISIT COUNTS (S0 - S9) ---");
            foreach (TrafficStateId st in Enum.GetValues(typeof(TrafficStateId)))
            {
                var meta = TrafficStateMetadata.All[st];
                sb.AppendLine($"{meta.Code} ({meta.Name,-24}) : {a.StateVisitCounts[st],4} activations");
            }

            _analyticsReportLabel.Text = sb.ToString();
        }
    }
}
