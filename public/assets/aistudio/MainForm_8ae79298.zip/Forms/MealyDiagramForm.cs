using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Controls;

namespace TrafficLightSimulator.Forms
{
    public sealed class MealyDiagramForm : Panel
    {
        private readonly TrafficController _controller;
        private readonly StateDiagramControl _diagramControl;
        private readonly DataGridView _transitionGrid;

        public MealyDiagramForm(TrafficController controller)
        {
            _controller = controller;
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(13, 18, 27);
            Padding = new Padding(14);

            var diagramCard = new Panel
            {
                Dock = DockStyle.Top,
                Height = 340,
                BackColor = Color.FromArgb(20, 28, 40),
                Padding = new Padding(10)
            };
            var diagramTitle = new Label
            {
                Text = "MEALY STATE TRANSITION MAP  ·  Select a state to activate its existing manual phase action",
                Dock = DockStyle.Top,
                Height = 28,
                ForeColor = Color.FromArgb(196, 181, 253),
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold),
                AutoEllipsis = true
            };
            _diagramControl = new StateDiagramControl(_controller) { Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 28, 40) };
            diagramCard.Controls.Add(_diagramControl);
            diagramCard.Controls.Add(diagramTitle);

            var tableCard = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(20, 28, 40),
                Padding = new Padding(10)
            };
            var tableTitle = new Label
            {
                Text = "TRANSITION TABLE",
                Dock = DockStyle.Top,
                Height = 30,
                ForeColor = Color.FromArgb(125, 166, 255),
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold)
            };
            _transitionGrid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(15, 22, 32),
                ForeColor = Color.FromArgb(226, 232, 240),
                GridColor = Color.FromArgb(45, 58, 76),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                EnableHeadersVisualStyles = false,
                BorderStyle = BorderStyle.None,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single,
                ColumnHeadersHeight = 34,
                RowTemplate = { Height = 30 },
                DataSource = MealyMachine.TransitionTable.ToList()
            };
            _transitionGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(34, 48, 67);
            _transitionGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(226, 232, 240);
            _transitionGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            _transitionGrid.DefaultCellStyle.BackColor = Color.FromArgb(20, 28, 40);
            _transitionGrid.DefaultCellStyle.ForeColor = Color.FromArgb(203, 213, 225);
            _transitionGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(48, 68, 98);
            _transitionGrid.DefaultCellStyle.SelectionForeColor = Color.White;
            _transitionGrid.DefaultCellStyle.Font = new Font("Segoe UI", 8.5F);
            _transitionGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(24, 34, 48);
            tableCard.Controls.Add(_transitionGrid);
            tableCard.Controls.Add(tableTitle);

            Controls.Add(tableCard);
            Controls.Add(diagramCard);
            _controller.SimulationUpdated += (_, _) => _diagramControl.Invalidate();
        }
    }
}
