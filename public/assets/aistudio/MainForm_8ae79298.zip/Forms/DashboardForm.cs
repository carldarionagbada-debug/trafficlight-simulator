using System;
using System.Drawing;
using System.Windows.Forms;
using TrafficLightSimulator.Controllers;
using TrafficLightSimulator.Controls;
using TrafficLightSimulator.Models;

namespace TrafficLightSimulator.Forms
{
    public sealed class DashboardForm : Panel
    {
        private readonly TrafficController _controller;
        private readonly IntersectionControl _intersectionControl;
        private readonly Label _mealyChainLabel;
        private readonly Label _monitorStatsLabel;

        public DashboardForm(TrafficController controller)
        {
            _controller = controller;
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(13, 18, 27);
            Padding = new Padding(12);

            var topBanner = new Panel
            {
                Dock = DockStyle.Top,
                Height = 72,
                BackColor = Color.FromArgb(22, 31, 45),
                Padding = new Padding(14, 9, 14, 9),
                Margin = new Padding(0, 0, 0, 10)
            };
            var bannerTitle = new Label
            {
                Text = "MEALY CONTROL FLOW",
                Dock = DockStyle.Top,
                Height = 18,
                Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(125, 166, 255)
            };
            _mealyChainLabel = new Label
            {
                Dock = DockStyle.Fill,
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(221, 214, 254),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            topBanner.Controls.Add(_mealyChainLabel);
            topBanner.Controls.Add(bannerTitle);

            var bottomMonitor = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 86,
                BackColor = Color.FromArgb(22, 31, 45),
                Padding = new Padding(14, 9, 14, 9)
            };
            var monitorTitle = new Label
            {
                Text = "LIVE SYSTEM MONITOR",
                Dock = DockStyle.Top,
                Height = 18,
                Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(74, 222, 128)
            };
            _monitorStatsLabel = new Label
            {
                Dock = DockStyle.Fill,
                Font = new Font("Consolas", 8.2f),
                ForeColor = Color.FromArgb(226, 232, 240),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            bottomMonitor.Controls.Add(_monitorStatsLabel);
            bottomMonitor.Controls.Add(monitorTitle);

            _intersectionControl = new IntersectionControl(_controller) { Dock = DockStyle.Fill, Margin = new Padding(0) };
            Controls.Add(_intersectionControl);
            Controls.Add(bottomMonitor);
            Controls.Add(topBanner);

            _controller.SimulationUpdated += (_, _) => RefreshView();
            RefreshView();
        }

        public void RefreshView()
        {
            var meta = TrafficStateMetadata.All[_controller.CurrentState];
            var nextMeta = TrafficStateMetadata.All[_controller.NextTransitionPreview.NextState];
            _mealyChainLabel.Text =
                $"INPUT  N:{_controller.Sensors[Direction.North].Congestion}  S:{_controller.Sensors[Direction.South].Congestion}  E:{_controller.Sensors[Direction.East].Congestion}  W:{_controller.Sensors[Direction.West].Congestion}     →     " +
                $"STATE  {meta.Code} ({meta.ShortName})     →     NEXT  {nextMeta.Code}     →     OUTPUT  {_controller.CurrentOutput.ActiveGreenSummary}";
            _monitorStatsLabel.Text =
                $"State {meta.Code} ({meta.Name})  •  Timer {_controller.PhaseElapsedSeconds:0.0}s / {_controller.CurrentInput.TargetPhaseDurationSeconds:0.0}s  •  Mode {(_controller.IsAutoMode ? "AUTO" : "MANUAL")}\n" +
                $"Vehicles {_controller.Analytics.TotalVehiclesProcessed}  •  Avg wait {_controller.Analytics.AverageWaitTimeSeconds:0.1}s  •  Pedestrians {_controller.Analytics.PedestrianCrossingsServed}  •  Emergency {(_controller.EmergencyActive ? _controller.EmergencyDirection.ToString() : "NONE")}  •  Rule {_controller.CurrentOutput.MealyRuleApplied}";
            _intersectionControl.Invalidate();
        }
    }
}
