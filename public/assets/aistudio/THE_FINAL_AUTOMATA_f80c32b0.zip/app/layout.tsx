import type { Metadata } from 'next';
import { Outfit, Plus_Jakarta_Sans, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';

const outfit = Outfit({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
});

const plexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: 'SignalFlow — Interactive Traffic Light & Intersection Simulator',
  description:
    'Interactive 4-way traffic signal control simulator featuring autonomous vehicle physics, finite state machine diagrams, synchronized signal timing waveforms, and real-time intersection telemetry.',
  openGraph: {
    title: 'SignalFlow — Interactive Traffic Light & Intersection Simulator',
    description:
      'Interactive 4-way traffic signal control simulator featuring autonomous vehicle physics, finite state machine diagrams, synchronized signal timing waveforms, and real-time intersection telemetry.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SignalFlow — Interactive Traffic Light & Intersection Simulator',
    description:
      'Interactive 4-way traffic signal control simulator featuring autonomous vehicle physics, finite state machine diagrams, synchronized signal timing waveforms, and real-time intersection telemetry.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${outfit.variable} ${jakarta.variable} ${plexMono.variable}`}
    >
      <body
        suppressHydrationWarning
        className="bg-[#09090b] text-[#f5f5f7] antialiased selection:bg-[#0A84FF]/30 selection:text-white font-sans"
      >
        {children}
      </body>
    </html>
  );
}
