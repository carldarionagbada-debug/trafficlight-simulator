'use client';

import React from 'react';

export type NavSection =
  | 'intersection'
  | 'diagram'
  | 'timing'
  | 'telemetry'
  | 'guide';

interface NavbarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
}

export default function Navbar({
  activeSection,
  onSelectSection,
}: NavbarProps) {
  const navItems: { id: NavSection; label: string }[] = [
    { id: 'intersection', label: 'Intersection' },
    { id: 'diagram', label: 'State Diagram' },
    { id: 'timing', label: 'Phase Timing' },
    { id: 'telemetry', label: 'Logic & Sensors' },
    { id: 'guide', label: 'System Guide' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full min-h-16 sm:min-h-[72px] px-4 sm:px-8 py-2.5 bg-black/45 backdrop-blur-3xl border-b border-white/[0.15] select-none flex items-center justify-center shadow-[0_6px_28px_rgba(0,0,0,0.45)]">
      <nav
        aria-label="Main Navigation"
        className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 rounded-2xl bg-white/[0.05] border border-white/[0.12] shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]"
      >
        {navItems.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectSection(item.id)}
              className={`h-9 px-3.5 sm:px-4 inline-flex items-center justify-center rounded-xl text-xs sm:text-[13px] font-semibold tracking-tight transition-all cursor-pointer leading-none whitespace-nowrap ${
                isActive
                  ? 'bg-[#0A84FF]/28 text-white border border-[#64D2FF]/50 shadow-[0_2px_12px_rgba(10,132,255,0.28),inset_0_1px_0_rgba(255,255,255,0.25)]'
                  : 'text-zinc-300 border border-transparent hover:bg-white/[0.08] hover:text-white'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
